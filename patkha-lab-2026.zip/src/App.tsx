/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { CRACKERS } from './data/crackers';
import { CrackerData, CrackerState } from './types';
import { soundEngine } from './audio/soundEngine';
import { FireworksEngine } from './canvas/FireworksEngine';
import { FestiveEnvironment } from './components/FestiveEnvironment';
import { Header } from './components/Header';
import { CrackerCard } from './components/CrackerCard';
import { InteractiveStage } from './components/InteractiveStage';
import { Heart } from 'lucide-react';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fireworksEngineRef = useRef<FireworksEngine | null>(null);

  // Cracker interaction state
  const [activeCracker, setActiveCracker] = useState<CrackerData | null>(null);
  const [crackerState, setCrackerState] = useState<CrackerState>('idle');
  const [fuseProgress, setFuseProgress] = useState<number>(0);
  const [isBurstAllActive, setIsBurstAllActive] = useState<boolean>(false);

  // Screen shake animation
  const [shakeIntensity, setShakeIntensity] = useState<number>(0);

  // Setup Fireworks Canvas Engine
  useEffect(() => {
    if (!canvasRef.current) return;

    const handleShake = (intensity: number) => {
      setShakeIntensity(intensity);
      setTimeout(() => setShakeIntensity(0), 220);
    };

    const engine = new FireworksEngine(canvasRef.current, handleShake);
    fireworksEngineRef.current = engine;

    const handleResize = () => {
      engine.resize();
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      engine.stop();
    };
  }, []);

  // 4-Step Realistic Burning Experience
  const igniteCracker = useCallback((cracker: CrackerData) => {
    // 1. Initialize Audio Context on user gesture
    soundEngine.init();

    // Reset previous ongoing timers
    soundEngine.stopFuseSizzle();
    soundEngine.stopContinuous();

    setActiveCracker(cracker);
    setCrackerState('selected');
    setFuseProgress(0);

    // STEP 1 & 2: Selection and Fuse Ignition
    setTimeout(() => {
      setCrackerState('fuse_burning');
      soundEngine.startFuseSizzle(cracker.fuseTime);

      const startTime = performance.now();
      const fuseDuration = cracker.fuseTime;

      const animateFuse = (now: number) => {
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / fuseDuration);
        setFuseProgress(progress);

        if (progress < 1) {
          requestAnimationFrame(animateFuse);
        } else {
          // STEP 3: EXPLOSION
          soundEngine.stopFuseSizzle();
          setCrackerState('exploding');

          // Play synchronized synthesized sound
          soundEngine.playCrackerSound(cracker.id);

          // Trigger particle explosion on canvas
          if (fireworksEngineRef.current) {
            fireworksEngineRef.current.triggerCracker(cracker.id);
          }

          // STEP 4: RESET / FINISH
          setTimeout(() => {
            setCrackerState('finished');
          }, cracker.duration);
        }
      };

      requestAnimationFrame(animateFuse);
    }, 220);
  }, []);

  // Replay active cracker
  const handleReplayActive = () => {
    if (activeCracker) {
      igniteCracker(activeCracker);
    }
  };

  // Dismiss stage
  const handleCloseStage = () => {
    soundEngine.stopFuseSizzle();
    soundEngine.stopContinuous();
    setActiveCracker(null);
    setCrackerState('idle');
    setFuseProgress(0);
  };

  // Grand Finale "BURST ALL"
  const handleBurstAll = () => {
    soundEngine.init();
    setIsBurstAllActive(true);
    handleCloseStage();

    // Trigger canvas grand fireworks show
    if (fireworksEngineRef.current) {
      fireworksEngineRef.current.triggerBurstAll();
    }

    // Trigger audio symphony
    soundEngine.playBurstAllSymphony();

    // Confetti celebration
    try {
      confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.6 },
        colors: ['#fbbf24', '#f43f5e', '#38bdf8', '#4ade80', '#c084fc']
      });

      setTimeout(() => {
        confetti({
          particleCount: 80,
          angle: 60,
          spread: 80,
          origin: { x: 0, y: 0.7 }
        });
        confetti({
          particleCount: 80,
          angle: 120,
          spread: 80,
          origin: { x: 1, y: 0.7 }
        });
      }, 1500);
    } catch {}

    // Auto reset after 8 seconds
    setTimeout(() => {
      setIsBurstAllActive(false);
    }, 7800);
  };

  const isAnyActive = crackerState === 'fuse_burning' || crackerState === 'exploding';

  return (
    <div
      className="relative min-h-[100dvh] text-slate-100 flex flex-col justify-between overflow-x-hidden bg-[#040612]"
      style={{
        transform:
          shakeIntensity > 0
            ? `translate(${(Math.random() - 0.5) * shakeIntensity}px, ${(Math.random() - 0.5) * shakeIntensity}px)`
            : undefined
      }}
    >
      {/* Immersive Diwali Night Sky, Skyline, Stars & Animated Diyas */}
      <FestiveEnvironment />

      {/* Full-Screen High-Performance Particle Fireworks Canvas */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-30 w-full h-full"
      />

      {/* Main Content Area */}
      <main className="relative z-20 flex-1 flex flex-col pb-8 sm:pb-12">
        {/* Festive Header */}
        <Header
          onBurstAll={handleBurstAll}
          isBurstAllActive={isBurstAllActive}
        />

        {/* 20 Cracker Cards Grid: 2 columns on mobile, 3 on tablet, 4-5 on desktop */}
        <section className="w-full max-w-7xl mx-auto px-2 min-[360px]:px-3 sm:px-4 py-2 sm:py-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 min-[360px]:gap-2.5 sm:gap-4 md:gap-5">
            {CRACKERS.map((cracker) => (
              <CrackerCard
                key={cracker.id}
                cracker={cracker}
                state={crackerState}
                fuseProgress={fuseProgress}
                isSelected={activeCracker?.id === cracker.id}
                isAnyActive={isAnyActive}
                onSelect={igniteCracker}
              />
            ))}
          </div>
        </section>

        {/* Floating Active Stage with Burning Fuse and Replay Controls */}
        <InteractiveStage
          activeCracker={activeCracker}
          state={crackerState}
          fuseProgress={fuseProgress}
          onReplay={handleReplayActive}
          onClose={handleCloseStage}
          isBurstAllActive={isBurstAllActive}
        />
      </main>

      {/* Footer with generous bottom clearance (pb-36) for mobile navigation bars and floating stage */}
      <footer className="relative z-20 pt-6 sm:pt-8 pb-36 sm:pb-16 px-4 text-center border-t border-slate-900 bg-slate-950/90 backdrop-blur-md pb-safe">
        <div className="max-w-4xl mx-auto flex flex-col items-center gap-3.5 text-xs text-slate-400">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5">
            <span className="text-amber-400 font-bold tracking-wide">PATKHA LAB 2026</span>
            <span className="text-slate-600">·</span>
            <span>Virtual Diwali Fireworks Experience</span>
            <span className="text-slate-600">·</span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/35 text-amber-300 font-semibold text-xs shadow-sm">
              <span className="text-amber-400/80 font-normal">Publisher:</span>
              <strong className="text-amber-200 font-bold tracking-wide">Satyam Mishar</strong>
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-slate-400 font-medium">
            <span>Made with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 animate-pulse" />
            <span>for Diwali 2026</span>
            <span className="text-slate-600">|</span>
            <span className="text-amber-400 font-bold">PATKHA LAB</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2.5 text-[11px] text-slate-500">
            <span>100% Eco-Friendly</span>
            <span>·</span>
            <span>Zero Smoke Pollution</span>
            <span>·</span>
            <span>Infinite Celebrations</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
