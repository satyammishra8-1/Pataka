import { CrackerData } from '../types';

export const CRACKERS: CrackerData[] = [
  {
    id: 'sutli_bomb',
    name: 'Sutli Bomb',
    hindiName: 'सुतली बम',
    category: 'bomb',
    categoryLabel: 'Heavy Bomb',
    tagline: 'The undisputed king of Diwali sound',
    description: 'Traditional cylindrical firecracker tightly wound with natural jute thread. Features a short countdown fuse, blinding flash, and a deep chest-thumping bass boom.',
    fuseTime: 1800,
    duration: 1600,
    dangerLevel: 5,
    primaryColor: '#15803d',
    secondaryColor: '#dc2626',
    sparkColors: ['#fbbf24', '#f97316', '#ef4444', '#ffffff'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Jute Bound Flash Bomb',
      altitude: 'Ground Shockwave'
    }
  },
  {
    id: 'atom_bomb',
    name: 'Atom Bomb',
    hindiName: 'एटम बम',
    category: 'bomb',
    categoryLabel: 'Explosive Bomb',
    tagline: 'Green foil triangular thunder',
    description: 'Iconic triangular cracker with decorative green foil packaging and red hazard borders. Delivers a dramatic flash, dense expanding particle cloud, and synthesized bass tremor.',
    fuseTime: 1600,
    duration: 1700,
    dangerLevel: 5,
    primaryColor: '#16a34a',
    secondaryColor: '#f59e0b',
    sparkColors: ['#22c55e', '#eab308', '#f97316', '#ffffff'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Triangle Foil Flash',
      altitude: 'Ground Blast'
    }
  },
  {
    id: 'ladi',
    name: 'Ladi',
    hindiName: 'लड़ी पटाखा',
    category: 'chain',
    categoryLabel: 'Garland Chain',
    tagline: 'Continuous machine-gun crackles',
    description: 'Traditional connected firecracker string of bright scarlet cylinders. Ignites in a rapid-fire sequential wave of bright flashes and staccato crackling pops.',
    fuseTime: 1400,
    duration: 3200,
    dangerLevel: 4,
    primaryColor: '#dc2626',
    secondaryColor: '#fbbf24',
    sparkColors: ['#ef4444', '#f59e0b', '#fef08a', '#ffffff'],
    specs: {
      noiseLevel: 'Very Loud',
      type: 'Connected Series String',
      altitude: 'Ground Runway'
    }
  },
  {
    id: 'rocket',
    name: 'Rocket',
    hindiName: 'रॉकेट',
    category: 'aerial',
    categoryLabel: 'Aerial Rocket',
    tagline: 'Soaring trail with skyburst',
    description: 'Traditional aerodynamic rocket with wooden guide stick and red nose cone. Shoots skyward with an ascending Doppler whistle before bursting into a multi-colored aerial peony.',
    fuseTime: 1700,
    duration: 2800,
    dangerLevel: 4,
    primaryColor: '#2563eb',
    secondaryColor: '#f97316',
    sparkColors: ['#38bdf8', '#fbbf24', '#f43f5e', '#a855f7'],
    specs: {
      noiseLevel: 'Very Loud',
      type: 'Ascending Projectile',
      altitude: 'High Aerial (80m)'
    }
  },
  {
    id: 'anaar',
    name: 'Anaar',
    hindiName: 'अनार',
    category: 'fountain',
    categoryLabel: 'Golden Fountain',
    tagline: 'Majestic fountain of golden sparks',
    description: 'Traditional conical fountain cracker wrapped in festive peacock motifs. Erupts into a continuous, towering fountain of golden sparkling embers with crackling sizzle.',
    fuseTime: 1500,
    duration: 4000,
    dangerLevel: 3,
    primaryColor: '#d97706',
    secondaryColor: '#f59e0b',
    sparkColors: ['#fef08a', '#f59e0b', '#fbbf24', '#ffffff'],
    specs: {
      noiseLevel: 'Sizzling',
      type: 'Continuous Conical Fountain',
      altitude: 'Mid-Air (12ft)'
    }
  },
  {
    id: 'chakri',
    name: 'Chakri',
    hindiName: 'चकरी',
    category: 'ground',
    categoryLabel: 'Ground Spinner',
    tagline: 'High-speed spinning galaxy of sparks',
    description: 'Traditional circular ground wheel firework. Spins at blistering speed on the floor, throwing hypnotic Archimedean spiral spark rings with a whirring Doppler hum.',
    fuseTime: 1500,
    duration: 4200,
    dangerLevel: 3,
    primaryColor: '#ca8a04',
    secondaryColor: '#dc2626',
    sparkColors: ['#eab308', '#f97316', '#3b82f6', '#ffffff'],
    specs: {
      noiseLevel: 'Moderate',
      type: 'Rotary Ground Wheel',
      altitude: 'Ground Level'
    }
  },
  {
    id: 'phuljhadi',
    name: 'Phuljhadi',
    hindiName: 'फुलझड़ी',
    category: 'sparkler',
    categoryLabel: 'Sparkler Stick',
    tagline: 'Delicate handheld golden magic',
    description: 'Beloved handheld sparkler stick coated in rich pyrotechnic composition. Emits a continuous, comforting cascade of bright branching golden star embers with gentle crackles.',
    fuseTime: 1200,
    duration: 4500,
    dangerLevel: 1,
    primaryColor: '#94a3b8',
    secondaryColor: '#f59e0b',
    sparkColors: ['#fef08a', '#fbbf24', '#ffffff', '#fed7aa'],
    specs: {
      noiseLevel: 'Gentle',
      type: 'Handheld Sparkler Wire',
      altitude: 'Handheld'
    }
  },
  {
    id: 'thousand_wala',
    name: '1000 Wala',
    hindiName: 'हज़ार वाला',
    category: 'chain',
    categoryLabel: 'Grand Chain',
    tagline: 'Non-stop barrage of 1000 explosions',
    description: 'Massive celebratory roll of interconnected red firecrackers. Creates a thunderous continuous wall of smoke, rapid-fire staccato flashes, and endless festive energy.',
    fuseTime: 1600,
    duration: 5200,
    dangerLevel: 5,
    primaryColor: '#b91c1c',
    secondaryColor: '#f59e0b',
    sparkColors: ['#dc2626', '#f59e0b', '#ffffff', '#facc15'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Grand Multi-Shot Chain',
      altitude: 'Ground Runway'
    }
  },
  {
    id: 'flower_pot',
    name: 'Flower Pot',
    hindiName: 'फ्लावर पॉट',
    category: 'fountain',
    categoryLabel: 'Floral Fountain',
    tagline: 'Multi-colored tall floral cascade',
    description: 'Premium ornate ceramic vase cracker. Sprays a majestic, tall rainbow fountain of emerald green, ruby red, and shimmering diamond sparks with pleasant crackling audio.',
    fuseTime: 1500,
    duration: 4200,
    dangerLevel: 3,
    primaryColor: '#9333ea',
    secondaryColor: '#10b981',
    sparkColors: ['#a855f7', '#34d399', '#f43f5e', '#fbbf24'],
    specs: {
      noiseLevel: 'Sizzling',
      type: 'Multi-Color Tall Fountain',
      altitude: 'Mid-Air (18ft)'
    }
  },
  {
    id: 'seven_shot',
    name: 'Seven Shot',
    hindiName: 'सेवन शॉट',
    category: 'aerial',
    categoryLabel: 'Multi-Shot Mortar',
    tagline: '7 sequential sky blooms in distinct colors',
    description: 'Multi-barrel launcher firing 7 distinct shells one after another into the night sky, blooming sequentially in Ruby Red, Emerald Green, Sapphire Blue, Golden Yellow, Violet, Orange, and Silver.',
    fuseTime: 1700,
    duration: 5500,
    dangerLevel: 4,
    primaryColor: '#0284c7',
    secondaryColor: '#e11d48',
    sparkColors: ['#ef4444', '#10b981', '#3b82f6', '#f59e0b', '#a855f7', '#f97316', '#ffffff'],
    specs: {
      noiseLevel: 'Very Loud',
      type: 'Sequential Aerial Repeater',
      altitude: 'High Sky (70m)'
    }
  },
  {
    id: 'red_bijli',
    name: 'Red Bijli',
    hindiName: 'लाल बिजली',
    category: 'bomb',
    categoryLabel: 'Snappy Cracker',
    tagline: 'Lightning fast snappy red pop',
    description: 'Compact classic red paper strip cracker. Fast fuse countdown followed by a crisp, sharp pop, bright crimson flash, and bouncing red paper fragments.',
    fuseTime: 1200,
    duration: 1200,
    dangerLevel: 2,
    primaryColor: '#ef4444',
    secondaryColor: '#fee2e2',
    sparkColors: ['#ef4444', '#f87171', '#fbbf24', '#ffffff'],
    specs: {
      noiseLevel: 'Loud',
      type: 'Single Paper Strip',
      altitude: 'Ground Flash'
    }
  },
  {
    id: 'pencil_cracker',
    name: 'Pencil Cracker',
    hindiName: 'पेंसिल पटाखा',
    category: 'sparkler',
    categoryLabel: 'Torch Jet',
    tagline: 'Vertical sparkling torch jet',
    description: 'Slender cylinder resembling a golden pencil. Shoots a high-velocity straight vertical beam of silver and golden stars with an energetic whistling sizzle.',
    fuseTime: 1400,
    duration: 3500,
    dangerLevel: 2,
    primaryColor: '#0d9488',
    secondaryColor: '#f59e0b',
    sparkColors: ['#2dd4bf', '#fde047', '#ffffff', '#38bdf8'],
    specs: {
      noiseLevel: 'Moderate',
      type: 'High-Velocity Vertical Jet',
      altitude: 'Mid-Air (8ft)'
    }
  },
  {
    id: 'twinkling_star',
    name: 'Twinkling Star',
    hindiName: 'ट्विंकलिंग स्टार',
    category: 'sparkler',
    categoryLabel: 'Star Cracker',
    tagline: 'Magical cluster of glittering starbursts',
    description: 'Five-pointed festive star cracker. Bursts into a floating cluster of glowing, shimmering star particles with gentle melodic chime frequencies and twinkling glitter.',
    fuseTime: 1500,
    duration: 3800,
    dangerLevel: 2,
    primaryColor: '#f59e0b',
    secondaryColor: '#8b5cf6',
    sparkColors: ['#fde047', '#c084fc', '#ffffff', '#67e8f9'],
    specs: {
      noiseLevel: 'Gentle',
      type: 'Geometric Starburst',
      altitude: 'Mid-Air (10ft)'
    }
  },
  {
    id: 'sky_shot',
    name: 'Sky Shot',
    hindiName: 'स्काई शॉट',
    category: 'aerial',
    categoryLabel: 'Aerial Mortar',
    tagline: 'Spectacular panoramic willow burst',
    description: 'Heavy single mortar shell. Launches with a deep physical thud, tracing a glowing comet tail straight to the heavens before bursting into an enormous panoramic spherical willow bloom.',
    fuseTime: 1800,
    duration: 3400,
    dangerLevel: 5,
    primaryColor: '#4f46e5',
    secondaryColor: '#f43f5e',
    sparkColors: ['#818cf8', '#fb7185', '#fde047', '#ffffff'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Heavy Mortar Shell',
      altitude: 'Maximum Sky (100m)'
    }
  },
  {
    id: 'mega_blast',
    name: 'Mega Blast',
    hindiName: 'मेगा ब्लास्ट',
    category: 'bomb',
    categoryLabel: 'Royal Finale',
    tagline: 'The ultimate cinematic grand finale',
    description: 'King of all virtual crackers with royal golden embossing. Triggers a multi-stage cinematic detonation with concentric shockwaves, 400+ glittering embers, and seismic sub-bass roar.',
    fuseTime: 2200,
    duration: 4200,
    dangerLevel: 5,
    primaryColor: '#e11d48',
    secondaryColor: '#facc15',
    sparkColors: ['#fbbf24', '#f43f5e', '#38bdf8', '#4ade80', '#c084fc', '#ffffff'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Multi-Stage Royal Flash',
      altitude: 'Full Screen Shockwave'
    }
  },
  {
    id: 'naagin_goli',
    name: 'Naagin Goli',
    hindiName: 'साँप की गोली',
    category: 'ground',
    categoryLabel: 'Snake Tablet',
    tagline: 'Growing carbon snake with sizzling embers',
    description: 'Iconic classic Diwali black tablet pellet. When ignited, smolders with an earthy sizzling sizzle, erupting into an expanding, curling black carbon snake with glowing embers.',
    fuseTime: 1200,
    duration: 4800,
    dangerLevel: 1,
    primaryColor: '#334155',
    secondaryColor: '#f97316',
    sparkColors: ['#f97316', '#fbbf24', '#64748b', '#0f172a'],
    specs: {
      noiseLevel: 'Sizzling',
      type: 'Thermal Carbon Snake',
      altitude: 'Ground Surface'
    }
  },
  {
    id: 'bullet_bomb',
    name: 'Bullet Bomb',
    hindiName: 'बुलेट बम',
    category: 'bomb',
    categoryLabel: 'Artillery Flash',
    tagline: 'Supersonic concussive gunshot blast',
    description: 'Gold-tipped artillery cylinder wrapped in scarlet hazard foil. Delivers an instantaneous supersonic crack and concussive shockwave with flying golden shrapnel sparks.',
    fuseTime: 1500,
    duration: 1500,
    dangerLevel: 4,
    primaryColor: '#eab308',
    secondaryColor: '#dc2626',
    sparkColors: ['#fbbf24', '#ef4444', '#facc15', '#ffffff'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Point-Blank Concussive Shell',
      altitude: 'Ground Blast'
    }
  },
  {
    id: 'smoke_bomb',
    name: 'Color Smoke Bomb',
    hindiName: 'रंगीन धुआँ',
    category: 'ground',
    categoryLabel: 'Smoke Canister',
    tagline: 'Vivid billowing clouds of festive smoke',
    description: 'Multi-vented festive canister spewing thick, billowing clouds of saffron, emerald green, and cyan smoke with a pressurized jet roar.',
    fuseTime: 1300,
    duration: 4500,
    dangerLevel: 2,
    primaryColor: '#06b6d4',
    secondaryColor: '#f97316',
    sparkColors: ['#f97316', '#10b981', '#06b6d4', '#fbbf24'],
    specs: {
      noiseLevel: 'Moderate',
      type: 'Pressurized Gas Generator',
      altitude: 'Ground Plume (8m)'
    }
  },
  {
    id: 'whistling_siren',
    name: 'Whistling Siren',
    hindiName: 'सीटी पटाखा',
    category: 'aerial',
    categoryLabel: 'Siren Rocket',
    tagline: 'Ear-piercing screeching acoustic whistle',
    description: 'Resonant acoustic cavity cylinder that screams into the air with an oscillating Doppler siren whistle before detonating in a sharp, crisp sky pop.',
    fuseTime: 1600,
    duration: 3200,
    dangerLevel: 3,
    primaryColor: '#facc15',
    secondaryColor: '#ea580c',
    sparkColors: ['#fde047', '#f97316', '#38bdf8', '#ffffff'],
    specs: {
      noiseLevel: 'Very Loud',
      type: 'Cavity Resonator Projectile',
      altitude: 'Mid-Sky (45m)'
    }
  },
  {
    id: 'hydro_bomb',
    name: 'Hydro Bomb',
    hindiName: 'हाइड्रो बम',
    category: 'bomb',
    categoryLabel: 'Double Sound Bomb',
    tagline: 'Iconic two-stage double sonic explosion',
    description: 'High-power dual-chamber bomb in electric cyan and silver. Produces a rapid double detonation: first a blinding acoustic flash pop, then 200ms later a massive ground-trembling bass explosion.',
    fuseTime: 1700,
    duration: 2200,
    dangerLevel: 5,
    primaryColor: '#0284c7',
    secondaryColor: '#e0e7ff',
    sparkColors: ['#38bdf8', '#818cf8', '#ffffff', '#fbbf24'],
    specs: {
      noiseLevel: 'Extremely Loud',
      type: 'Dual-Chamber Double Flash',
      altitude: 'Ground Shockwave'
    }
  }
];

