import React from 'react';
import { Sparkles, Flame, Zap } from 'lucide-react';

interface HeaderProps {
  onBurstAll: () => void;
  isBurstAllActive: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onBurstAll,
  isBurstAllActive
}) => {
  return (
    <header className="relative w-full pt-3 sm:pt-7 pb-3 sm:pb-4 px-2.5 sm:px-4 max-w-7xl mx-auto flex flex-col items-center text-center">
      {/* Top Utility Bar: Burst All CTA (Mobile & Desktop optimized) */}
      <div className="w-full flex items-center justify-center mb-3 sm:mb-6 px-1">
        {/* Prominent "BURST ALL" Diwali Dhamaka Button - Touch target >= 48px */}
        <button
          onClick={onBurstAll}
          disabled={isBurstAllActive}
          className={`w-full max-w-sm sm:w-auto min-h-[48px] px-5 sm:px-7 py-3 rounded-2xl font-black text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2.5 shadow-2xl transition-all duration-200 active:scale-95 shrink-0 select-none touch-manipulation ${
            isBurstAllActive
              ? 'bg-rose-600 text-white animate-pulse'
              : 'bg-gradient-to-r from-amber-400 via-amber-500 to-rose-500 hover:from-amber-300 hover:to-rose-400 text-slate-950 shadow-amber-500/40 hover:shadow-amber-500/60'
          }`}
        >
          <Sparkles className="w-4 h-4 animate-spin shrink-0 text-slate-950" />
          <span className="truncate">🎆 BURST ALL – DIWALI DHAMAKA!</span>
        </button>
      </div>

      {/* Main Festive Header Branding */}
      <div className="space-y-1 sm:space-y-2 mb-2 sm:mb-3">
        <div className="inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] sm:text-xs font-bold tracking-wider uppercase">
          <Flame className="w-3 h-3 text-amber-400" />
          <span>Virtual Diwali Fireworks 2026</span>
          <Flame className="w-3 h-3 text-amber-400" />
        </div>

        <h1 className="text-2xl min-[380px]:text-3xl sm:text-5xl md:text-6xl font-black font-cinzel tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-rose-400 drop-shadow-[0_2px_12px_rgba(245,158,11,0.35)] px-1">
          🪔 HAPPY DIWALI 🪔
        </h1>

        <p className="text-base min-[380px]:text-xl sm:text-2xl md:text-3xl font-extrabold text-amber-300 font-outfit">
          Welcome to PATKHA LAB 2026
        </p>

        <p className="text-xs sm:text-base text-slate-300 max-w-lg mx-auto font-medium leading-relaxed px-2">
          Unlimited Masti. One Crazy Diwali!
        </p>

        {/* Small Instruction Notice */}
        <div className="pt-1.5">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-slate-900/90 border border-amber-500/30 text-[11px] sm:text-xs text-amber-300 font-semibold shadow-inner">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            Tap any cracker to light it up!
          </span>
        </div>
      </div>

    </header>
  );
};
