import React, { useEffect, useState } from 'react';

export const FestiveEnvironment: React.FC = () => {
  // Ambient distant fireworks
  const [distantPuffs, setDistantPuffs] = useState<
    { id: number; x: number; y: number; color: string; size: number }[]
  >([]);

  useEffect(() => {
    const colors = ['#f59e0b', '#ef4444', '#38bdf8', '#a855f7', '#10b981', '#facc15'];

    const interval = setInterval(() => {
      // 40% chance every 2.8 seconds
      if (Math.random() < 0.6) {
        const newPuff = {
          id: Date.now() + Math.random(),
          x: 10 + Math.random() * 80, // %
          y: 8 + Math.random() * 28,  // %
          color: colors[Math.floor(Math.random() * colors.length)],
          size: 14 + Math.random() * 22
        };

        setDistantPuffs((prev) => [...prev.slice(-4), newPuff]);

        setTimeout(() => {
          setDistantPuffs((prev) => prev.filter((p) => p.id !== newPuff.id));
        }, 1800);
      }
    }, 2400);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
      {/* Deep Midnight Blue to Black Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#030614] via-[#080d24] to-[#040612]" />

      {/* Subtle Starry Night Texture */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage: `radial-gradient(1.5px 1.5px at 20px 30px, #ffffff, rgba(0,0,0,0)),
            radial-gradient(1px 1px at 80px 140px, #fde047, rgba(0,0,0,0)),
            radial-gradient(1.5px 1.5px at 150px 70px, #ffffff, rgba(0,0,0,0)),
            radial-gradient(1px 1px at 240px 180px, #93c5fd, rgba(0,0,0,0)),
            radial-gradient(1.5px 1.5px at 320px 40px, #ffffff, rgba(0,0,0,0)),
            radial-gradient(1px 1px at 420px 120px, #fef08a, rgba(0,0,0,0))`,
          backgroundSize: '480px 240px'
        }}
      />

      {/* Floating Warm Golden Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-amber-500/10 rounded-full blur-[120px]" />
      <div className="absolute top-10 left-10 w-96 h-96 bg-indigo-600/10 rounded-full blur-[100px]" />
      <div className="absolute top-20 right-10 w-96 h-96 bg-purple-600/10 rounded-full blur-[100px]" />

      {/* Distant Fireworks Puffs */}
      {distantPuffs.map((puff) => (
        <div
          key={puff.id}
          className="absolute rounded-full transition-all duration-1000 ease-out animate-ping"
          style={{
            left: `${puff.x}%`,
            top: `${puff.y}%`,
            width: `${puff.size}px`,
            height: `${puff.size}px`,
            backgroundColor: puff.color,
            boxShadow: `0 0 24px ${puff.color}`,
            opacity: 0.75
          }}
        />
      ))}

      {/* Distant City Skyline Silhouette */}
      <div className="absolute bottom-0 inset-x-0 h-40 opacity-25">
        <svg
          viewBox="0 0 1440 220"
          className="w-full h-full object-cover"
          preserveAspectRatio="none"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Back Layer of Buildings */}
          <path
            d="M0 160 L60 160 L60 120 L100 120 L100 160 L140 160 L140 90 L180 90 L180 160 L240 160 L240 140 L280 140 L280 160 L350 160 L350 110 L400 110 L400 160 L480 160 L480 80 L520 80 L520 160 L600 160 L600 130 L650 130 L650 160 L730 160 L730 100 L770 100 L770 160 L840 160 L840 120 L890 120 L890 160 L960 160 L960 85 L1010 85 L1010 160 L1100 160 L1100 135 L1160 135 L1160 160 L1240 160 L1240 95 L1290 95 L1290 160 L1380 160 L1380 115 L1440 115 L1440 220 L0 220 Z"
            fill="#090f2e"
          />
          {/* Front Layer Silhouette */}
          <path
            d="M0 180 L40 180 L40 150 L90 150 L90 180 L160 180 L160 130 L210 130 L210 180 L290 180 L290 155 L340 155 L340 180 L440 180 L440 125 L490 125 L490 180 L560 180 L560 145 L620 145 L620 180 L700 180 L700 120 L750 120 L750 180 L820 180 L820 150 L870 150 L870 180 L940 180 L940 110 L990 110 L990 180 L1070 180 L1070 140 L1130 140 L1130 180 L1210 180 L1210 125 L1260 125 L1260 180 L1340 180 L1340 145 L1440 145 L1440 220 L0 220 Z"
            fill="#050818"
          />
          {/* Subtle Warm Lit Windows */}
          <rect x="170" y="140" width="3" height="4" fill="#fbbf24" opacity="0.8" />
          <rect x="175" y="148" width="3" height="4" fill="#fbbf24" opacity="0.6" />
          <rect x="460" y="140" width="4" height="4" fill="#fbbf24" opacity="0.9" />
          <rect x="470" y="152" width="4" height="4" fill="#fbbf24" opacity="0.7" />
          <rect x="720" y="135" width="3" height="5" fill="#fde047" opacity="0.8" />
          <rect x="965" y="125" width="4" height="4" fill="#f59e0b" opacity="0.8" />
          <rect x="975" y="140" width="4" height="4" fill="#fbbf24" opacity="0.75" />
          <rect x="1230" y="140" width="3" height="4" fill="#fbbf24" opacity="0.8" />
        </svg>
      </div>

      {/* Decorative Corner Rangoli Patterns */}
      <div className="absolute -top-16 -left-16 w-56 h-56 opacity-20 text-amber-400 rotate-45 pointer-events-none">
        <svg viewBox="0 0 100 100" fill="currentColor">
          <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="1" fill="none" />
          <circle cx="50" cy="50" r="35" stroke="currentColor" strokeWidth="1" strokeDasharray="3 2" fill="none" />
          <circle cx="50" cy="50" r="25" stroke="currentColor" strokeWidth="1" fill="none" />
          <path d="M50 5 L50 95 M5 50 L95 50 M18 18 L82 82 M18 82 L82 18" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>
      <div className="absolute -top-16 -right-16 w-56 h-56 opacity-20 text-amber-400 -rotate-45 pointer-events-none">
        <svg viewBox="0 0 100 100" fill="currentColor">
          <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="1" fill="none" />
          <circle cx="50" cy="50" r="35" stroke="currentColor" strokeWidth="1" strokeDasharray="3 2" fill="none" />
          <circle cx="50" cy="50" r="25" stroke="currentColor" strokeWidth="1" fill="none" />
          <path d="M50 5 L50 95 M5 50 L95 50 M18 18 L82 82 M18 82 L82 18" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>

      {/* Animated Glowing Diyas at Left & Right Edges */}
      <div className="absolute bottom-6 left-6 hidden sm:flex items-center gap-3">
        <DiyaItem />
      </div>
      <div className="absolute bottom-6 right-6 hidden sm:flex items-center gap-3">
        <DiyaItem />
      </div>
    </div>
  );
};

export const DiyaItem: React.FC<{ size?: string }> = ({ size = 'w-10 h-10' }) => {
  return (
    <div className={`relative ${size} flex flex-col items-center justify-end`}>
      {/* Flame */}
      <div className="animate-diya mb-0.5 z-10">
        <svg width="18" height="26" viewBox="0 0 18 26" fill="none">
          <defs>
            <radialGradient id="flame_glow" cx="9" cy="18" r="9" gradientUnits="userSpaceOnUse">
              <stop stopColor="#ffffff" />
              <stop offset="0.3" stopColor="#fef08a" />
              <stop offset="0.7" stopColor="#f59e0b" />
              <stop offset="1" stopColor="#dc2626" />
            </radialGradient>
          </defs>
          <path
            d="M9 1 C11 7, 17 14, 16 19 C15 23, 12 25, 9 25 C6 25, 3 23, 2 19 C1 14, 7 7, 9 1 Z"
            fill="url(#flame_glow)"
          />
        </svg>
      </div>
      {/* Diya Clay Pot Base */}
      <svg width="38" height="14" viewBox="0 0 38 14" fill="none">
        <path
          d="M2 3 Q19 16 36 3 Q33 13 19 13 Q5 13 2 3 Z"
          fill="#b45309"
          stroke="#78350f"
          strokeWidth="1.2"
        />
        {/* Clay rim */}
        <ellipse cx="19" cy="3" rx="17" ry="2.5" fill="#d97706" />
      </svg>
      {/* Warm Ground Cast Glow */}
      <div className="absolute -bottom-2 w-14 h-4 bg-amber-500/30 rounded-full blur-md" />
    </div>
  );
};
