import React from 'react';
import { CrackerData, CrackerState } from '../types';
import { CrackerArt } from './CrackerArt';
import { Sparkles, Flame, RotateCcw, X } from 'lucide-react';

interface InteractiveStageProps {
  activeCracker: CrackerData | null;
  state: CrackerState;
  fuseProgress: number;
  onReplay: () => void;
  onClose: () => void;
  isBurstAllActive?: boolean;
}

export const InteractiveStage: React.FC<InteractiveStageProps> = ({
  activeCracker,
  state,
  fuseProgress,
  onReplay,
  onClose,
  isBurstAllActive = false
}) => {
  if (isBurstAllActive) {
    return (
      <div className="fixed top-3 sm:top-6 left-1/2 -translate-x-1/2 z-50 px-4 sm:px-7 py-3 sm:py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-rose-600 to-amber-400 text-slate-950 shadow-2xl shadow-amber-500/50 border border-amber-200 animate-pulse text-center max-w-md w-[92%] select-none">
        <h2 className="text-lg sm:text-2xl md:text-3xl font-black font-cinzel tracking-wider text-slate-950 flex items-center justify-center gap-1.5 sm:gap-2">
          <span>🎆</span>
          <span>DIWALI HO TOH AISI! 🔥</span>
          <span>🎆</span>
        </h2>
        <p className="text-[10px] sm:text-xs font-bold text-slate-950/90 mt-1">
          Grand Patkha Dhamaka Finale in progress!
        </p>
      </div>
    );
  }

  if (!activeCracker || state === 'idle') return null;

  const isBurning = state === 'fuse_burning';
  const isExploding = state === 'exploding';
  const isFinished = state === 'finished';

  return (
    <div className="fixed bottom-3 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 w-[95%] max-w-lg bg-slate-950/95 backdrop-blur-xl border border-amber-500/40 rounded-2xl p-3 sm:p-5 shadow-2xl shadow-amber-500/30 select-none pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      <div className="flex items-center justify-between gap-2.5 sm:gap-4">
        {/* Left: Cracker Mini Artwork with Burning Fuse */}
        <div className="relative w-14 h-14 sm:w-16 sm:h-16 shrink-0 bg-slate-900/90 rounded-xl p-1 flex items-center justify-center border border-slate-800">
          <CrackerArt
            id={activeCracker.id}
            className="w-12 h-12 sm:w-14 sm:h-14"
            isBurning={isBurning}
            fuseProgress={fuseProgress}
          />
          {isBurning && (
            <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 rounded-full animate-ping" />
          )}
        </div>

        {/* Center: Stage Title and Live Status */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <h4 className="text-sm sm:text-base font-bold text-white truncate">
              {activeCracker.name}
            </h4>
            <span className="text-[11px] sm:text-xs text-amber-400 font-semibold truncate">
              ({activeCracker.hindiName})
            </span>
          </div>

          <div className="mt-0.5 sm:mt-1 flex items-center gap-2">
            {isBurning && (
              <span className="text-[11px] sm:text-xs font-bold text-amber-300 flex items-center gap-1 animate-pulse">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>GET READY! Burning fuse... {Math.round(fuseProgress * 100)}%</span>
              </span>
            )}
            {isExploding && (
              <span className="text-[11px] sm:text-xs font-black text-rose-400 flex items-center gap-1 animate-bounce">
                <Flame className="w-3.5 h-3.5 shrink-0" />
                <span>BOOM! SPECTACULAR BLAST!</span>
              </span>
            )}
            {isFinished && (
              <span className="text-[11px] sm:text-xs text-slate-400">
                Cracker finished! Ready to ignite again.
              </span>
            )}
          </div>

          {/* Fuse progress bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className={`h-full transition-all duration-75 ${
                isExploding
                  ? 'bg-rose-500 w-full'
                  : isBurning
                  ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-rose-500'
                  : 'bg-emerald-500 w-full'
              }`}
              style={{
                width: isBurning
                  ? `${Math.round(fuseProgress * 100)}%`
                  : isExploding || isFinished
                  ? '100%'
                  : '0%'
              }}
            />
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {isFinished && (
            <button
              onClick={onReplay}
              className="min-h-[44px] px-3 sm:px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold rounded-xl shadow-lg shadow-amber-500/25 flex items-center gap-1.5 text-xs active:scale-95 transition-all touch-manipulation"
              title="Light this cracker again"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              <span>Light Again</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/90 transition-colors flex items-center justify-center active:scale-95 touch-manipulation"
            title="Close stage"
            aria-label="Close stage"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
