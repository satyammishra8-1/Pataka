import React from 'react';
import { CrackerId } from '../types';

interface CrackerArtProps {
  id: CrackerId;
  className?: string;
  isBurning?: boolean;
  fuseProgress?: number; // 0 (start) to 1 (ignited into cracker)
}

export const CrackerArt: React.FC<CrackerArtProps> = ({
  id,
  className = 'w-32 h-32',
  isBurning = false,
  fuseProgress = 0
}) => {
  // Enhanced realistic moving fuse flame with glowing embers and smoke trail
  const renderFuseSpark = (
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    curveControlX?: number,
    curveControlY?: number
  ) => {
    if (!isBurning) return null;

    // Support quadratic bezier interpolation if control point provided
    let curX: number;
    let curY: number;
    const t = Math.max(0, Math.min(1, fuseProgress));

    if (curveControlX !== undefined && curveControlY !== undefined) {
      const u = 1 - t;
      curX = u * u * startX + 2 * u * t * curveControlX + t * t * endX;
      curY = u * u * startY + 2 * u * t * curveControlY + t * t * endY;
    } else {
      curX = startX + (endX - startX) * t;
      curY = startY + (endY - startY) * t;
    }

    return (
      <g className="fuse-spark-group pointer-events-none">
        {/* Subtle rising smoke trail behind flame */}
        <ellipse
          cx={curX - 2}
          cy={curY - 6}
          rx="4.5"
          ry="3"
          fill="rgba(200, 200, 210, 0.45)"
          className="animate-pulse"
        />
        <ellipse
          cx={curX + 1}
          cy={curY - 11}
          rx="6"
          ry="3.8"
          fill="rgba(180, 180, 195, 0.3)"
        />

        {/* Outer radial glow halo */}
        <circle
          cx={curX}
          cy={curY}
          r="13"
          fill="rgba(251, 146, 60, 0.4)"
          filter="drop-shadow(0 0 6px rgba(245, 158, 11, 0.8))"
        />
        <circle cx={curX} cy={curY} r="8" fill="rgba(251, 191, 36, 0.85)" />

        {/* Teardrop flame shape */}
        <path
          d={`M ${curX} ${curY - 9} C ${curX + 3.5} ${curY - 3}, ${curX + 4} ${curY + 2}, ${curX} ${curY + 3.5} C ${curX - 4} ${curY + 2}, ${curX - 3.5} ${curY - 3}, ${curX} ${curY - 9} Z`}
          fill="#f59e0b"
          className="animate-pulse"
        />
        <path
          d={`M ${curX} ${curY - 6} C ${curX + 2} ${curY - 2}, ${curX + 2} ${curY + 1.5}, ${curX} ${curY + 2} C ${curX - 2} ${curY + 1.5}, ${curX - 2} ${curY - 2}, ${curX} ${curY - 6} Z`}
          fill="#ffffff"
        />

        {/* Dancing micro-sparks */}
        <circle cx={curX - 4} cy={curY - 6} r="1.3" fill="#ef4444" />
        <circle cx={curX + 5} cy={curY - 4} r="1.5" fill="#facc15" />
        <circle cx={curX + 2} cy={curY - 10} r="1.1" fill="#ffffff" />
        <circle cx={curX - 5} cy={curY + 2} r="1" fill="#fb923c" />
      </g>
    );
  };

  switch (id) {
    /**
     * 1. SUTLI BOMB: Realistic cylindrical firecracker with visible criss-cross jute twine wrapping,
     * thick fiber cords, red & gold authentic label, and traditional braided cotton fuse.
     */
    case 'sutli_bomb':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="sutli_jute_cylinder" x1="40" y1="45" x2="120" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#143217" />
              <stop offset="0.2" stopColor="#1b4d21" />
              <stop offset="0.55" stopColor="#2e6f36" />
              <stop offset="0.85" stopColor="#183f1d" />
              <stop offset="1" stopColor="#0d2410" />
            </linearGradient>

            <pattern id="jute_twine_weave" width="8" height="8" patternUnits="userSpaceOnUse">
              <path d="M0 0 L8 8 M8 0 L0 8" stroke="#ca8a04" strokeWidth="1.2" strokeOpacity="0.85" />
              <path d="M4 0 L8 4 M0 4 L4 8 M4 0 L0 4 M8 4 L4 8" stroke="#a16207" strokeWidth="0.8" strokeOpacity="0.6" />
            </pattern>

            <linearGradient id="sutli_label_grad" x1="44" y1="78" x2="116" y2="108" gradientUnits="userSpaceOnUse">
              <stop stopColor="#991b1b" />
              <stop offset="0.5" stopColor="#dc2626" />
              <stop offset="1" stopColor="#7f1d1d" />
            </linearGradient>

            <filter id="shadow_deep" x="-10%" y="-10%" width="125%" height="130%">
              <feDropShadow dx="0" dy="6" stdDeviation="5" floodColor="#000000" floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Cast Shadow */}
          <ellipse cx="80" cy="144" rx="44" ry="9" fill="#000000" opacity="0.5" filter="blur(3px)" />

          {/* Braided Fuse String */}
          <path
            d="M80 48 C75 32, 94 22, 88 8"
            stroke="#e2e8f0"
            strokeWidth="3.6"
            strokeDasharray="3 1.5"
            strokeLinecap="round"
          />
          <path
            d="M80 48 C75 32, 94 22, 88 8"
            stroke="#78350f"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          {renderFuseSpark(88, 8, 80, 48, 94, 26)}

          {/* Main Cylindrical Body with Jute Winding */}
          <rect
            x="40"
            y="48"
            width="80"
            height="88"
            rx="9"
            fill="url(#sutli_jute_cylinder)"
            stroke="#0f2910"
            strokeWidth="2.5"
            filter="url(#shadow_deep)"
          />
          <rect x="40" y="48" width="80" height="88" rx="9" fill="url(#jute_twine_weave)" />

          {/* Jute Twine Relief Bands (Horizontal Winding) */}
          <ellipse cx="80" cy="48" rx="40" ry="8" fill="#143217" stroke="#ca8a04" strokeWidth="2" />
          <path d="M40 68 Q80 76 120 68" stroke="#ca8a04" strokeWidth="3" fill="none" />
          <path d="M40 70 Q80 78 120 70" stroke="#78350f" strokeWidth="1" fill="none" opacity="0.7" />
          <path d="M40 118 Q80 126 120 118" stroke="#ca8a04" strokeWidth="3" fill="none" />
          <path d="M40 120 Q80 128 120 120" stroke="#78350f" strokeWidth="1" fill="none" opacity="0.7" />

          {/* Authentic Red & Gold Paper Label */}
          <g filter="url(#shadow_deep)">
            <rect x="46" y="76" width="68" height="34" rx="3" fill="url(#sutli_label_grad)" stroke="#facc15" strokeWidth="1.2" />
            <rect x="48" y="78" width="64" height="30" fill="none" stroke="#fef08a" strokeWidth="0.8" strokeDasharray="3 1.5" />
            <text x="80" y="91" textAnchor="middle" fill="#fef08a" fontSize="8.5" fontWeight="900" fontFamily="sans-serif" letterSpacing="0.8">
              SUTLI BOMB
            </text>
            <text x="80" y="101" textAnchor="middle" fill="#ffffff" fontSize="7" fontWeight="800" fontFamily="sans-serif">
              ★ 555 SPECIAL ★
            </text>
          </g>
        </svg>
      );

    /**
     * 2. ATOM BOMB: Triangular green metallic foil-wrapped cracker with folded foil seams,
     * red hazard border, and golden crest.
     */
    case 'atom_bomb':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="atom_metallic_foil" x1="80" y1="36" x2="135" y2="134" gradientUnits="userSpaceOnUse">
              <stop stopColor="#4ade80" />
              <stop offset="0.25" stopColor="#22c55e" />
              <stop offset="0.6" stopColor="#16a34a" />
              <stop offset="0.85" stopColor="#15803d" />
              <stop offset="1" stopColor="#052e16" />
            </linearGradient>
            <linearGradient id="atom_sheen" x1="45" y1="50" x2="115" y2="120" gradientUnits="userSpaceOnUse">
              <stop stopColor="#ffffff" stopOpacity="0.4" />
              <stop offset="0.5" stopColor="#86efac" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="50" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Fuse at Apex */}
          <path d="M80 38 C72 24, 92 16, 85 6" stroke="#ca8a04" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(85, 6, 80, 38, 92, 20)}

          {/* Triangular Foil Body */}
          <polygon
            points="80,36 138,135 22,135"
            fill="url(#atom_metallic_foil)"
            stroke="#b91c1c"
            strokeWidth="4.5"
            strokeLinejoin="round"
          />

          {/* Foil Reflection Sheen */}
          <polygon points="80,38 78,133 26,133" fill="url(#atom_sheen)" />

          {/* Folded Seam Lines */}
          <line x1="80" y1="36" x2="80" y2="135" stroke="#86efac" strokeWidth="1.8" strokeOpacity="0.75" />
          <line x1="80" y1="36" x2="48" y2="135" stroke="#14532d" strokeWidth="1.4" />
          <line x1="80" y1="36" x2="112" y2="135" stroke="#14532d" strokeWidth="1.4" />

          {/* Red and Gold Circular Atom Emblem */}
          <circle cx="80" cy="98" r="23" fill="#dc2626" stroke="#fbbf24" strokeWidth="2.5" />
          <circle cx="80" cy="98" r="18" fill="#991b1b" stroke="#facc15" strokeWidth="1" strokeDasharray="3 1.5" />

          {/* Gold Star */}
          <polygon points="80,84 83,93 92,93 85,99 88,108 80,103 72,108 75,99 68,93 77,93" fill="#facc15" />
          <text x="80" y="117" textAnchor="middle" fill="#ffffff" fontSize="7.5" fontWeight="900" fontFamily="sans-serif">
            ATOM 999
          </text>
        </svg>
      );

    /**
     * 3. LADI: Connected garland string of scarlet firecracker cylinders
     * with gunpowder caps, gold threads, and authentic packaging.
     */
    case 'ladi':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="ladi_cylinder_grad" x1="0" y1="0" x2="48" y2="0" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f87171" />
              <stop offset="0.2" stopColor="#ef4444" />
              <stop offset="0.65" stopColor="#dc2626" />
              <stop offset="1" stopColor="#7f1d1d" />
            </linearGradient>
          </defs>

          {/* Central Braided Core Rope */}
          <path d="M80 10 L80 152" stroke="#ca8a04" strokeWidth="3" strokeDasharray="4 2" strokeLinecap="round" />
          {renderFuseSpark(80, 10, 80, 45)}

          {/* Top Hanging Ring */}
          <circle cx="80" cy="12" r="5" stroke="#facc15" strokeWidth="2.5" fill="none" />

          {/* Interconnected Staggered Cracker Cylinders */}
          {[26, 46, 66, 86, 106, 126].map((y, idx) => (
            <g key={idx}>
              {/* Left Tube */}
              <rect x="22" y={y} width="52" height="15" rx="2.5" fill="url(#ladi_cylinder_grad)" stroke="#991b1b" strokeWidth="1" />
              {/* Dark Gunpowder Cap on Outer Tip */}
              <rect x="22" y={y} width="5" height="15" rx="1.5" fill="#1e293b" />
              <rect x="33" y={y + 3} width="10" height="9" fill="#facc15" rx="1" />
              {/* Gold Connection Thread */}
              <line x1="74" y1={y + 7.5} x2="80" y2={y + 7.5} stroke="#f59e0b" strokeWidth="1.8" />

              {/* Right Tube */}
              <rect x="86" y={y + 8} width="52" height="15" rx="2.5" fill="url(#ladi_cylinder_grad)" stroke="#991b1b" strokeWidth="1" />
              <rect x="133" y={y + 8} width="5" height="15" rx="1.5" fill="#1e293b" />
              <rect x="117" y={y + 11} width="10" height="9" fill="#facc15" rx="1" />
              <line x1="80" y1={y + 15.5} x2="86" y2={y + 15.5} stroke="#f59e0b" strokeWidth="1.8" />
            </g>
          ))}
        </svg>
      );

    /**
     * 4. ROCKET: Aerodynamic missile with bright red nose cone, star-printed body,
     * wooden stabilizer stick, nozzle exhaust rim, and burning fuse.
     */
    case 'rocket':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="rocket_metallic_body" x1="68" y1="42" x2="92" y2="108" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38bdf8" />
              <stop offset="0.3" stopColor="#2563eb" />
              <stop offset="0.75" stopColor="#1d4ed8" />
              <stop offset="1" stopColor="#0f172a" />
            </linearGradient>
            <linearGradient id="rocket_cone_3d" x1="80" y1="16" x2="80" y2="44" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f87171" />
              <stop offset="0.6" stopColor="#dc2626" />
              <stop offset="1" stopColor="#991b1b" />
            </linearGradient>
          </defs>

          {/* Wooden Stabilizer Guide Stick */}
          <line x1="80" y1="106" x2="80" y2="156" stroke="#b45309" strokeWidth="3.2" strokeLinecap="round" />
          <line x1="80.5" y1="106" x2="80.5" y2="156" stroke="#fde047" strokeWidth="0.8" strokeOpacity="0.4" />

          {/* Exhaust Nozzle & Fuse */}
          <path d="M78 108 C73 118, 85 125, 77 136" stroke="#f59e0b" strokeWidth="2.8" strokeLinecap="round" />
          {renderFuseSpark(77, 136, 78, 108, 85, 122)}

          {/* Aerodynamic Stabilizer Tail Fins */}
          <polygon points="68,90 54,106 68,106" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
          <polygon points="92,90 106,106 92,106" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />

          {/* Cylindrical Motor Body */}
          <rect
            x="68"
            y="44"
            width="24"
            height="62"
            rx="3"
            fill="url(#rocket_metallic_body)"
            stroke="#fbbf24"
            strokeWidth="1.5"
          />

          {/* Printed Star Accents on Body */}
          <circle cx="80" cy="58" r="3.5" fill="#fde047" />
          <circle cx="80" cy="74" r="3.5" fill="#fde047" />
          <circle cx="80" cy="90" r="3.5" fill="#fde047" />
          <line x1="68" y1="66" x2="92" y2="66" stroke="#fbbf24" strokeWidth="1.2" />
          <line x1="68" y1="82" x2="92" y2="82" stroke="#fbbf24" strokeWidth="1.2" />

          {/* Sharp Conical Nose Cone */}
          <polygon points="80,16 95,44 65,44" fill="url(#rocket_cone_3d)" stroke="#facc15" strokeWidth="1.2" />
        </svg>
      );

    /**
     * 5. ANAAR: Terracotta conical fountain pot wrapped with peacock & diya prints,
     * silver foil neck, and top ignition fuse.
     */
    case 'anaar':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="anaar_terracotta" x1="40" y1="45" x2="120" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f59e0b" />
              <stop offset="0.35" stopColor="#d97706" />
              <stop offset="0.75" stopColor="#b45309" />
              <stop offset="1" stopColor="#451a03" />
            </linearGradient>
            <linearGradient id="silver_foil_tip" x1="72" y1="32" x2="88" y2="46" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f8fafc" />
              <stop offset="0.5" stopColor="#cbd5e1" />
              <stop offset="1" stopColor="#64748b" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="46" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Top Fuse */}
          <path d="M80 32 C74 20, 88 14, 82 5" stroke="#f59e0b" strokeWidth="2.8" strokeLinecap="round" />
          {renderFuseSpark(82, 5, 80, 32, 88, 16)}

          {/* Silver Protective Foil Cap */}
          <polygon points="72,46 88,46 83,32 77,32" fill="url(#silver_foil_tip)" stroke="#475569" strokeWidth="1" />

          {/* Conical Fountain Body */}
          <path
            d="M72 46 L36 132 C36 139, 124 139, 124 132 L88 46 Z"
            fill="url(#anaar_terracotta)"
            stroke="#78350f"
            strokeWidth="2.2"
          />

          {/* Ornate Gold Filigree Rings */}
          <path d="M46 104 Q80 114 114 104" stroke="#fef08a" strokeWidth="3" fill="none" />
          <path d="M56 78 Q80 86 104 78" stroke="#fef08a" strokeWidth="2.2" fill="none" />

          {/* Diya / Peacock Crest */}
          <ellipse cx="80" cy="98" rx="15" ry="7.5" fill="#dc2626" stroke="#fde047" strokeWidth="1.5" />
          <path d="M80 83 C84 88, 84 92, 80 94 C76 92, 76 88, 80 83 Z" fill="#facc15" />

          {/* Solid Base Rim */}
          <ellipse cx="80" cy="132" rx="44" ry="6.5" fill="#78350f" stroke="#ca8a04" strokeWidth="1.8" />
        </svg>
      );

    /**
     * 6. CHAKRI: Realistic flat circular ground spinner with spiral grooved wings,
     * central metallic eyelet, and rim ignition fuse.
     */
    case 'chakri':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="chakri_metallic_wheel" cx="80" cy="80" r="62" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fef08a" />
              <stop offset="0.25" stopColor="#facc15" />
              <stop offset="0.55" stopColor="#ea580c" />
              <stop offset="0.85" stopColor="#b91c1c" />
              <stop offset="1" stopColor="#450a0a" />
            </radialGradient>
          </defs>

          {/* Cast Ground Shadow */}
          <ellipse cx="80" cy="142" rx="55" ry="9" fill="#000000" opacity="0.4" filter="blur(3px)" />

          {/* Outer Wheel Rim */}
          <circle cx="80" cy="80" r="60" fill="url(#chakri_metallic_wheel)" stroke="#facc15" strokeWidth="3" />

          {/* Swirling Spiral Blades */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
            <path
              key={deg}
              d="M80 80 Q98 58 126 54"
              stroke="#fbbf24"
              strokeWidth="2.8"
              transform={`rotate(${deg} 80 80)`}
              strokeLinecap="round"
            />
          ))}

          {/* Concentric Guide Grooves */}
          <circle cx="80" cy="80" r="44" stroke="#dc2626" strokeWidth="2.8" strokeDasharray="6 3" fill="none" />
          <circle cx="80" cy="80" r="28" stroke="#f59e0b" strokeWidth="2.4" fill="none" />

          {/* Central Steel Eyelet Rivet */}
          <circle cx="80" cy="80" r="11" fill="#0f172a" stroke="#f8fafc" strokeWidth="2" />
          <circle cx="80" cy="80" r="4.5" fill="#ffffff" />

          {/* Tangential Rim Ignition Fuse */}
          <path d="M136 60 C146 50, 148 38, 142 26" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(142, 26, 136, 60, 148, 42)}
        </svg>
      );

    /**
     * 7. PHULJHADI: Thin handheld metallic sparkler wire with textured pyrotechnic coating,
     * bare steel handle, and burning tip.
     */
    case 'phuljhadi':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Bare Steel Wire Handle */}
          <line x1="80" y1="96" x2="80" y2="152" stroke="#94a3b8" strokeWidth="3.2" strokeLinecap="round" />
          <line x1="80" y1="96" x2="80" y2="152" stroke="#e2e8f0" strokeWidth="1.2" strokeLinecap="round" />

          {/* Pyrotechnic Granular Coated Section */}
          <line x1="80" y1="18" x2="80" y2="96" stroke="#334155" strokeWidth="6.5" strokeLinecap="round" />
          <line x1="80" y1="18" x2="80" y2="96" stroke="#64748b" strokeWidth="5" strokeDasharray="2 3" strokeLinecap="round" />
          <line x1="80" y1="18" x2="80" y2="96" stroke="#cbd5e1" strokeWidth="1.8" strokeDasharray="1.5 4" />

          {/* Top Sparkler Tip */}
          {renderFuseSpark(80, 14, 80, 36)}
          {!isBurning && (
            <circle cx="80" cy="18" r="4" fill="#fbbf24" stroke="#f59e0b" strokeWidth="1.2" />
          )}
        </svg>
      );

    /**
     * 8. 1000 WALA: Massive coiled firecracker roll with concentric scarlet tubes,
     * golden seal insignia, and thick leading fuse.
     */
    case 'thousand_wala':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="thousand_roll" cx="80" cy="80" r="64" gradientUnits="userSpaceOnUse">
              <stop stopColor="#ef4444" />
              <stop offset="0.6" stopColor="#b91c1c" />
              <stop offset="1" stopColor="#450a0a" />
            </radialGradient>
          </defs>

          {/* Cast Shadow */}
          <ellipse cx="80" cy="144" rx="56" ry="9" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Large Cylindrical Roll Disc */}
          <circle cx="80" cy="80" r="62" fill="url(#thousand_roll)" stroke="#facc15" strokeWidth="3" />

          {/* Concentric Tied Cracker Tube Rows */}
          <circle cx="80" cy="80" r="54" stroke="#facc15" strokeWidth="2.5" strokeDasharray="4 2" fill="none" />
          <circle cx="80" cy="80" r="46" stroke="#ffffff" strokeWidth="2" strokeDasharray="3 2" fill="none" strokeOpacity="0.8" />
          <circle cx="80" cy="80" r="38" stroke="#facc15" strokeWidth="2.5" strokeDasharray="4 2" fill="none" />
          <circle cx="80" cy="80" r="30" stroke="#ffffff" strokeWidth="2" strokeDasharray="3 2" fill="none" strokeOpacity="0.8" />

          {/* Center Ornate Royal Seal */}
          <circle cx="80" cy="80" r="23" fill="#991b1b" stroke="#fde047" strokeWidth="2.5" />
          <text x="80" y="76" textAnchor="middle" fill="#fde047" fontSize="12" fontWeight="900" fontFamily="sans-serif">
            1000
          </text>
          <text x="80" y="89" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="800" fontFamily="sans-serif">
            WALA
          </text>

          {/* Leading Fuse Rope */}
          <path d="M136 44 C148 34, 146 18, 138 8" stroke="#f59e0b" strokeWidth="3.2" strokeLinecap="round" />
          {renderFuseSpark(138, 8, 136, 44, 148, 22)}
        </svg>
      );

    /**
     * 9. FLOWER POT: Ornate colourful ceramic fountain container with metallic purple glaze,
     * emerald accents, and gold collar.
     */
    case 'flower_pot':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="pot_ceramic_grad" x1="45" y1="46" x2="115" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#c084fc" />
              <stop offset="0.3" stopColor="#9333ea" />
              <stop offset="0.75" stopColor="#6b21a8" />
              <stop offset="1" stopColor="#2e1065" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="44" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Top Fuse */}
          <path d="M80 34 C74 22, 88 15, 82 5" stroke="#f59e0b" strokeWidth="2.8" strokeLinecap="round" />
          {renderFuseSpark(82, 5, 80, 34, 88, 18)}

          {/* Gold Neck Collar */}
          <rect x="68" y="34" width="24" height="12" rx="2.5" fill="#facc15" stroke="#ca8a04" strokeWidth="1.2" />

          {/* Ornate Ceramic Vase Body */}
          <path
            d="M68 46 C48 60, 40 92, 46 116 C50 132, 110 132, 114 116 C120 92, 112 60, 92 46 Z"
            fill="url(#pot_ceramic_grad)"
            stroke="#facc15"
            strokeWidth="2.2"
          />

          {/* Floral Rosette Emblem */}
          <circle cx="80" cy="86" r="17" fill="#10b981" stroke="#fde047" strokeWidth="1.8" />
          <polygon points="80,74 83,82 92,82 85,88 88,96 80,91 72,96 75,88 68,82 77,82" fill="#facc15" />
          <text x="80" y="117" textAnchor="middle" fill="#fef08a" fontSize="7.5" fontWeight="800" fontFamily="sans-serif">
            FLOWER POT
          </text>
        </svg>
      );

    /**
     * 10. SEVEN SHOT: Multi-barrel launcher with 7 visible firing tubes at the top,
     * caution stripes, and side fuse.
     */
    case 'seven_shot':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="launcher_box" x1="40" y1="44" x2="120" y2="142" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0284c7" />
              <stop offset="0.45" stopColor="#0369a1" />
              <stop offset="1" stopColor="#082f49" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="46" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Main Launcher Box */}
          <rect x="42" y="44" width="76" height="92" rx="7" fill="url(#launcher_box)" stroke="#facc15" strokeWidth="2.2" />

          {/* 7 Firing Barrel Muzzles Visible on Top */}
          {[48, 64, 80, 96, 112].map((tx, idx) => (
            <ellipse key={idx} cx={tx} cy="44" rx="5.5" ry="3.2" fill="#0f172a" stroke="#cbd5e1" strokeWidth="1" />
          ))}

          {/* Hazard Caution Stripes */}
          <line x1="42" y1="68" x2="118" y2="68" stroke="#f59e0b" strokeWidth="3.5" />
          <line x1="42" y1="114" x2="118" y2="114" stroke="#f59e0b" strokeWidth="3.5" />

          <text x="80" y="90" textAnchor="middle" fill="#ffffff" fontSize="13.5" fontWeight="900" fontFamily="sans-serif" letterSpacing="0.5">
            7 SHOT
          </text>
          <text x="80" y="103" textAnchor="middle" fill="#38bdf8" fontSize="8" fontWeight="800" fontFamily="sans-serif">
            AERIAL MULTI-COLOR
          </text>

          {/* Side Ignition Fuse */}
          <path d="M118 60 C130 50, 136 36, 130 22" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(130, 22, 118, 60, 138, 40)}
        </svg>
      );

    /**
     * 11. RED BIJLI: Small red paper-wrapped cracker with authentic crimped ends
     * and thin cotton string fuse.
     */
    case 'red_bijli':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Shadow */}
          <ellipse cx="80" cy="136" rx="22" ry="6" fill="#000000" opacity="0.45" filter="blur(2px)" />

          {/* Compact Red Cylinder */}
          <rect x="66" y="52" width="28" height="70" rx="3.5" fill="#dc2626" stroke="#991b1b" strokeWidth="1.8" />
          {/* Crimped Paper Bands */}
          <line x1="66" y1="70" x2="94" y2="70" stroke="#facc15" strokeWidth="2.5" />
          <line x1="66" y1="104" x2="94" y2="104" stroke="#facc15" strokeWidth="2.5" />

          <text x="80" y="89" textAnchor="middle" fill="#ffffff" fontSize="9.5" fontWeight="900" fontFamily="sans-serif">
            BIJLI
          </text>

          {/* Thin Braided Fuse */}
          <path d="M80 52 C74 40, 88 30, 82 16" stroke="#f59e0b" strokeWidth="2.4" strokeLinecap="round" />
          {renderFuseSpark(82, 16, 80, 52, 88, 32)}
        </svg>
      );

    /**
     * 12. PENCIL CRACKER: Slender pencil-shaped firework with metallic finish,
     * pointed spark nozzle, and star decals.
     */
    case 'pencil_cracker':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="pencil_metallic" x1="72" y1="40" x2="88" y2="140" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2dd4bf" />
              <stop offset="0.4" stopColor="#0f766e" />
              <stop offset="1" stopColor="#042f2e" />
            </linearGradient>
          </defs>

          {/* Fuse at Nozzle */}
          <path d="M80 30 C75 20, 86 14, 80 6" stroke="#f59e0b" strokeWidth="2.6" strokeLinecap="round" />
          {renderFuseSpark(80, 6, 80, 30, 86, 16)}

          {/* Pointed Pyrotechnic Tip */}
          <polygon points="80,30 88,46 72,46" fill="#facc15" stroke="#ca8a04" strokeWidth="1.2" />

          {/* Slender Pencil Shaft */}
          <rect x="72" y="46" width="16" height="94" rx="2.5" fill="url(#pencil_metallic)" stroke="#fbbf24" strokeWidth="1.5" />

          {/* Spiral Gold Stripes */}
          <line x1="72" y1="62" x2="88" y2="68" stroke="#fef08a" strokeWidth="1.8" />
          <line x1="72" y1="84" x2="88" y2="90" stroke="#fef08a" strokeWidth="1.8" />
          <line x1="72" y1="106" x2="88" y2="112" stroke="#fef08a" strokeWidth="1.8" />
        </svg>
      );

    /**
     * 13. TWINKLING STAR: Decorative gold foil star-shaped cracker with inner mandala
     * engravings and center fuse.
     */
    case 'twinkling_star':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="star_foil" x1="30" y1="26" x2="130" y2="136" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fef08a" />
              <stop offset="0.4" stopColor="#f59e0b" />
              <stop offset="0.8" stopColor="#d97706" />
              <stop offset="1" stopColor="#78350f" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="42" ry="8" fill="#000000" opacity="0.4" filter="blur(3px)" />

          {/* Center Ignition Fuse */}
          <path d="M80 72 C70 56, 92 38, 82 18" stroke="#fbbf24" strokeWidth="2.8" strokeLinecap="round" />
          {renderFuseSpark(82, 18, 80, 72, 92, 42)}

          {/* 5-Pointed Star Outer Body */}
          <polygon
            points="80,24 96,68 142,68 106,96 120,140 80,114 40,140 54,96 18,68 64,68"
            fill="url(#star_foil)"
            stroke="#92400e"
            strokeWidth="3"
            strokeLinejoin="round"
          />

          {/* Inner Decorative Mandala Star */}
          <polygon
            points="80,48 88,72 112,72 93,87 100,110 80,95 60,110 67,87 48,72 72,72"
            fill="#dc2626"
            stroke="#fef08a"
            strokeWidth="1.6"
          />
          <circle cx="80" cy="80" r="7" fill="#ffffff" />
        </svg>
      );

    /**
     * 14. SKY SHOT: Traditional heavy aerial mortar canister in matte dark navy
     * with hazard warning stripes and launch rim.
     */
    case 'sky_shot':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="skyshot_heavy_canister" x1="44" y1="38" x2="116" y2="142" gradientUnits="userSpaceOnUse">
              <stop stopColor="#312e81" />
              <stop offset="0.35" stopColor="#1e1b4b" />
              <stop offset="0.8" stopColor="#0f172a" />
              <stop offset="1" stopColor="#020617" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="44" ry="8" fill="#000000" opacity="0.5" filter="blur(3px)" />

          {/* Fuse at Base Rim */}
          <path d="M116 112 C128 102, 134 86, 128 72" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(128, 72, 116, 112, 134, 90)}

          {/* Mortar Canister Body */}
          <rect
            x="46"
            y="38"
            width="68"
            height="102"
            rx="7"
            fill="url(#skyshot_heavy_canister)"
            stroke="#f43f5e"
            strokeWidth="2.8"
          />

          {/* Top Muzzle Rim */}
          <ellipse cx="80" cy="38" rx="34" ry="7.5" fill="#0f172a" stroke="#fbbf24" strokeWidth="2.2" />
          <ellipse cx="80" cy="38" rx="24" ry="4.5" fill="#020617" />

          {/* Gold Hazard Stripes */}
          <rect x="46" y="60" width="68" height="6.5" fill="#facc15" />
          <rect x="46" y="118" width="68" height="6.5" fill="#facc15" />

          <text x="80" y="88" textAnchor="middle" fill="#ffffff" fontSize="12.5" fontWeight="900" fontFamily="sans-serif" letterSpacing="0.8">
            SKY SHOT
          </text>
          <text x="80" y="100" textAnchor="middle" fill="#f43f5e" fontSize="7.5" fontWeight="800" fontFamily="sans-serif">
            AERIAL WILLOW 120M
          </text>
        </svg>
      );

    /**
     * 15. MEGA BLAST: Large premium royal finale firework with deep crimson metallic body,
     * gold crown embossing, thick double braided fuse, and royal cords.
     */
    case 'mega_blast':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="mega_royal_crimson" x1="34" y1="38" x2="126" y2="142" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f43f5e" />
              <stop offset="0.25" stopColor="#e11d48" />
              <stop offset="0.65" stopColor="#be123c" />
              <stop offset="1" stopColor="#4c0519" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="52" ry="9" fill="#000000" opacity="0.5" filter="blur(3px)" />

          {/* Dual Braided Gold Fuse */}
          <path d="M80 38 C74 24, 96 16, 88 5" stroke="#facc15" strokeWidth="3.6" strokeLinecap="round" />
          {renderFuseSpark(88, 5, 80, 38, 96, 20)}

          {/* Large Royal Cylinder Body */}
          <rect
            x="34"
            y="38"
            width="92"
            height="100"
            rx="9"
            fill="url(#mega_royal_crimson)"
            stroke="#facc15"
            strokeWidth="3.2"
          />

          {/* Ornate Golden Cords */}
          <path d="M34 60 Q80 72 126 60" stroke="#facc15" strokeWidth="3.2" fill="none" />
          <path d="M34 116 Q80 128 126 116" stroke="#facc15" strokeWidth="3.2" fill="none" />

          {/* Royal Crown Emblem */}
          <path d="M66 87 L72 78 L80 85 L88 78 L94 87 Z" fill="#facc15" />
          <rect x="66" y="89" width="28" height="3.5" fill="#facc15" rx="1" />

          <text x="80" y="105" textAnchor="middle" fill="#ffffff" fontSize="11.5" fontWeight="900" fontFamily="sans-serif" letterSpacing="1">
            MEGA BLAST
          </text>
          <text x="80" y="114" textAnchor="middle" fill="#fef08a" fontSize="7" fontWeight="800" fontFamily="sans-serif">
            ROYAL FINALE 2026
          </text>
        </svg>
      );

    /**
     * 16. NAAGIN GOLI: Traditional black carbon snake pellet tablet
     */
    case 'naagin_goli':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="tablet_pellet" cx="80" cy="80" r="38" gradientUnits="userSpaceOnUse">
              <stop stopColor="#334155" />
              <stop offset="0.65" stopColor="#0f172a" />
              <stop offset="1" stopColor="#020617" />
            </radialGradient>
            <linearGradient id="matchbox_tray" x1="30" y1="90" x2="130" y2="140" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f59e0b" />
              <stop offset="0.5" stopColor="#d97706" />
              <stop offset="1" stopColor="#78350f" />
            </linearGradient>
          </defs>

          {/* Tray base */}
          <ellipse cx="80" cy="140" rx="55" ry="9" fill="#000000" opacity="0.45" filter="blur(3px)" />
          <path d="M25 105 L35 138 C35 142, 125 142, 125 138 L135 105 Z" fill="url(#matchbox_tray)" stroke="#ca8a04" strokeWidth="1.5" />
          <line x1="30" y1="120" x2="130" y2="120" stroke="#fef08a" strokeWidth="1" strokeDasharray="3 2" />

          {/* Central Cotton Fuse */}
          <path d="M80 65 C72 48, 92 34, 84 14" stroke="#e2e8f0" strokeWidth="2.8" strokeLinecap="round" />
          <path d="M80 65 C72 48, 92 34, 84 14" stroke="#ca8a04" strokeWidth="1.5" strokeDasharray="2 2" strokeLinecap="round" />
          {renderFuseSpark(84, 14, 80, 65, 92, 38)}

          {/* Black Carbon Tablet Pellet */}
          <ellipse cx="80" cy="88" rx="36" ry="24" fill="url(#tablet_pellet)" stroke="#475569" strokeWidth="2.5" />
          <ellipse cx="80" cy="88" rx="30" ry="18" fill="none" stroke="#64748b" strokeWidth="1.2" strokeDasharray="4 2" />

          {/* Embossed Snake Spiral Motif */}
          <path
            d="M80 88 Q88 80 84 76 Q76 72 74 80 Q72 88 80 92 Q88 94 92 88"
            stroke="#94a3b8"
            strokeWidth="2.2"
            fill="none"
            strokeLinecap="round"
          />

          <text x="80" y="130" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="900" fontFamily="sans-serif">
            NAAGIN GOLI
          </text>
        </svg>
      );

    /**
     * 17. BULLET BOMB: Golden-pointed artillery shell with red & gold wrapper
     */
    case 'bullet_bomb':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bullet_gold_tip" x1="68" y1="20" x2="92" y2="60" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fef08a" />
              <stop offset="0.4" stopColor="#eab308" />
              <stop offset="1" stopColor="#854d0e" />
            </linearGradient>
            <linearGradient id="bullet_red_body" x1="64" y1="60" x2="96" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#ef4444" />
              <stop offset="0.3" stopColor="#dc2626" />
              <stop offset="0.75" stopColor="#991b1b" />
              <stop offset="1" stopColor="#450a0a" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="36" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Fuse at side */}
          <path d="M96 90 C110 82, 118 68, 112 52" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(112, 52, 96, 90, 120, 72)}

          {/* Sharp Gold Bullet Tip */}
          <path
            d="M80 18 C88 28, 95 44, 96 60 L64 60 C65 44, 72 28, 80 18 Z"
            fill="url(#bullet_gold_tip)"
            stroke="#ca8a04"
            strokeWidth="1.8"
          />

          {/* Cylindrical Shell Body */}
          <rect x="64" y="60" width="32" height="74" rx="2" fill="url(#bullet_red_body)" stroke="#ca8a04" strokeWidth="2" />

          {/* Gold Artillery Bands */}
          <rect x="64" y="80" width="32" height="6" fill="#facc15" />
          <rect x="64" y="112" width="32" height="6" fill="#facc15" />

          <text x="80" y="102" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900" fontFamily="sans-serif">
            BULLET
          </text>

          {/* Brass Base Rim */}
          <ellipse cx="80" cy="134" rx="16" ry="4" fill="#ca8a04" stroke="#facc15" strokeWidth="1" />
        </svg>
      );

    /**
     * 18. COLOR SMOKE BOMB: Striped canister with top smoke vent ports
     */
    case 'smoke_bomb':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="smoke_body" x1="48" y1="45" x2="112" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0891b2" />
              <stop offset="0.5" stopColor="#06b6d4" />
              <stop offset="1" stopColor="#155e75" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="44" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Fuse at top rim */}
          <path d="M80 40 C74 26, 92 18, 85 6" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
          {renderFuseSpark(85, 6, 80, 40, 92, 22)}

          {/* Canister Body */}
          <rect x="50" y="42" width="60" height="94" rx="6" fill="url(#smoke_body)" stroke="#facc15" strokeWidth="2" />

          {/* Tri-Color Decorative Stripes */}
          <rect x="50" y="60" width="60" height="12" fill="#f97316" />
          <rect x="50" y="72" width="60" height="12" fill="#ffffff" />
          <rect x="50" y="84" width="60" height="12" fill="#10b981" />

          {/* Top Smoke Vent Mesh */}
          <ellipse cx="80" cy="42" rx="30" ry="7" fill="#1e293b" stroke="#e2e8f0" strokeWidth="1.5" />
          <circle cx="70" cy="42" r="2.5" fill="#020617" />
          <circle cx="80" cy="42" r="3" fill="#020617" />
          <circle cx="90" cy="42" r="2.5" fill="#020617" />

          <text x="80" y="114" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900" fontFamily="sans-serif">
            TRI-COLOR SMOKE
          </text>
        </svg>
      );

    /**
     * 19. WHISTLING SIREN: Aerodynamic whistle rocket with acoustic flute vents
     */
    case 'whistling_siren':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="siren_grad" x1="65" y1="35" x2="95" y2="115" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fde047" />
              <stop offset="0.35" stopColor="#f59e0b" />
              <stop offset="0.75" stopColor="#ea580c" />
              <stop offset="1" stopColor="#c2410c" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="148" rx="28" ry="7" fill="#000000" opacity="0.4" filter="blur(3px)" />

          {/* Guide stick */}
          <line x1="80" y1="110" x2="80" y2="154" stroke="#d97706" strokeWidth="3" strokeLinecap="round" />

          {/* Fuse at nozzle */}
          <path d="M78 112 C72 122, 85 130, 78 140" stroke="#f59e0b" strokeWidth="2.6" strokeLinecap="round" />
          {renderFuseSpark(78, 140, 78, 112, 85, 126)}

          {/* Side aerodynamic fins */}
          <polygon points="68,92 56,110 68,110" fill="#facc15" stroke="#d97706" strokeWidth="1" />
          <polygon points="92,92 104,110 92,110" fill="#facc15" stroke="#d97706" strokeWidth="1" />

          {/* Cylinder Tube */}
          <rect x="68" y="38" width="24" height="72" rx="3" fill="url(#siren_grad)" stroke="#ca8a04" strokeWidth="1.8" />

          {/* Whistle Acoustic Flute Slots */}
          <rect x="76" y="44" width="8" height="4" rx="1.5" fill="#1e293b" />
          <rect x="76" y="52" width="8" height="4" rx="1.5" fill="#1e293b" />
          <rect x="76" y="60" width="8" height="4" rx="1.5" fill="#1e293b" />

          {/* Flute Conical Mouthpiece Tip */}
          <polygon points="80,20 92,38 68,38" fill="#ef4444" stroke="#b91c1c" strokeWidth="1.2" />

          <text x="80" y="86" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="900" fontFamily="sans-serif">
            SIREN
          </text>
        </svg>
      );

    /**
     * 20. HYDRO BOMB: High-power dual-chamber double sound cylinder
     */
    case 'hydro_bomb':
      return (
        <svg viewBox="0 0 160 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="hydro_foil" x1="45" y1="40" x2="115" y2="135" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38bdf8" />
              <stop offset="0.3" stopColor="#0284c7" />
              <stop offset="0.75" stopColor="#0369a1" />
              <stop offset="1" stopColor="#075985" />
            </linearGradient>
          </defs>

          {/* Shadow */}
          <ellipse cx="80" cy="144" rx="46" ry="8" fill="#000000" opacity="0.45" filter="blur(3px)" />

          {/* Double Fuse on Top */}
          <path d="M80 40 C75 26, 94 18, 88 6" stroke="#facc15" strokeWidth="3.5" strokeLinecap="round" />
          {renderFuseSpark(88, 6, 80, 40, 95, 22)}

          {/* Main Dual Chamber Body */}
          <rect x="44" y="40" width="72" height="96" rx="8" fill="url(#hydro_foil)" stroke="#38bdf8" strokeWidth="2.5" />

          {/* Dual Chamber Dividing Band */}
          <rect x="44" y="84" width="72" height="8" fill="#e2e8f0" stroke="#0284c7" strokeWidth="1" />

          {/* Lightning Double Sound Emblem */}
          <polygon points="80,52 74,66 82,66 76,80 88,64 80,64" fill="#facc15" stroke="#ca8a04" strokeWidth="0.8" />

          <text x="80" y="104" textAnchor="middle" fill="#ffffff" fontSize="11" fontWeight="900" fontFamily="sans-serif">
            HYDRO BOMB
          </text>
          <text x="80" y="116" textAnchor="middle" fill="#38bdf8" fontSize="7" fontWeight="800" fontFamily="sans-serif">
            2-IN-1 DOUBLE SOUND
          </text>
        </svg>
      );

    default:
      return null;
  }
};
