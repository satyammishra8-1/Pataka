import React from 'react';
import { CrackerData, CrackerState } from '../types';
import { CrackerArt } from './CrackerArt';
import { Flame, Sparkles, Volume2 } from 'lucide-react';

interface CrackerCardProps {
  cracker: CrackerData;
  state: CrackerState;
  fuseProgress: number;
  isSelected: boolean;
  isAnyActive: boolean;
  onSelect: (cracker: CrackerData) => void;
}

export const CrackerCard: React.FC<CrackerCardProps> = ({
  cracker,
  state,
  fuseProgress,
  isSelected,
  isAnyActive,
  onSelect
}) => {
  const isDimmed = isAnyActive && !isSelected;
  const isBurning = isSelected && state === 'fuse_burning';
  const isExploding = isSelected && state === 'exploding';

  return (
    <div
      onClick={() => onSelect(cracker)}
      className={`group relative rounded-2xl p-2.5 min-[360px]:p-3.5 sm:p-5 cursor-pointer transition-all duration-300 flex flex-col justify-between overflow-hidden border select-none touch-manipulation active:scale-[0.98] ${
        isSelected
          ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-[#1e1338] border-amber-400 ring-2 ring-amber-400/60 shadow-2xl shadow-amber-500/30 scale-[1.01] sm:scale-[1.02] z-20'
          : isDimmed
          ? 'bg-slate-950/70 border-slate-900 opacity-35 grayscale-[35%]'
          : 'bg-slate-950/85 hover:bg-slate-900/90 border-slate-800/80 hover:border-amber-500/40 hover:shadow-xl hover:shadow-amber-500/10'
      }`}
    >
      {/* Decorative top corner accent glow */}
      <div
        className="absolute -top-10 -right-10 w-24 h-24 rounded-full blur-2xl transition-opacity duration-300 pointer-events-none"
        style={{
          backgroundColor: cracker.primaryColor,
          opacity: isSelected ? 0.45 : 0.15
        }}
      />

      {/* Top Header: Category and Danger Flame */}
      <div className="flex items-center justify-between gap-1 mb-1.5 sm:mb-2">
        <span className="text-[9px] min-[360px]:text-[10px] sm:text-[11px] font-bold text-amber-300 uppercase tracking-wider truncate">
          {cracker.categoryLabel}
        </span>
        <div
          className="flex items-center gap-0.5 text-xs text-slate-400 shrink-0"
          title={`Danger Level: ${cracker.dangerLevel}/5`}
        >
          {Array.from({ length: 5 }).map((_, i) => (
            <Flame
              key={i}
              className={`w-2.5 h-2.5 min-[360px]:w-3 min-[360px]:h-3 sm:w-3.5 sm:h-3.5 ${
                i < cracker.dangerLevel ? 'text-amber-500 fill-amber-500' : 'text-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Center Cracker Illustration with Burning Fuse */}
      <div className="relative py-1.5 sm:py-4 flex items-center justify-center min-h-[105px] min-[360px]:min-h-[120px] sm:min-h-[140px]">
        {/* Glow behind cracker */}
        <div
          className={`absolute inset-0 rounded-full blur-xl transition-all duration-500 pointer-events-none ${
            isBurning ? 'bg-amber-500/35 scale-125' : 'bg-transparent'
          }`}
        />

        <div className={`transition-transform duration-300 ${isSelected ? 'scale-110' : 'group-hover:scale-105'}`}>
          <CrackerArt
            id={cracker.id}
            className="w-20 h-20 min-[360px]:w-24 min-[360px]:h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 drop-shadow-2xl"
            isBurning={isBurning}
            fuseProgress={fuseProgress}
          />
        </div>

        {/* State Banners */}
        {isBurning && (
          <div className="absolute top-1 px-2 py-0.5 min-[360px]:px-2.5 min-[360px]:py-1 bg-amber-400 text-slate-950 font-black text-[9px] min-[360px]:text-[10px] sm:text-xs rounded-full shadow-lg shadow-amber-500/50 animate-bounce flex items-center gap-1 z-10">
            <Sparkles className="w-2.5 h-2.5 min-[360px]:w-3 min-[360px]:h-3 animate-spin shrink-0" />
            <span className="whitespace-nowrap">BURNING FUSE...</span>
          </div>
        )}

        {isExploding && (
          <div className="absolute top-1 px-2 py-0.5 min-[360px]:px-2.5 min-[360px]:py-1 bg-rose-600 text-white font-black text-[9px] min-[360px]:text-[10px] sm:text-xs rounded-full shadow-lg shadow-rose-600/50 animate-pulse flex items-center gap-1 z-10">
            <Flame className="w-2.5 h-2.5 min-[360px]:w-3 min-[360px]:h-3 shrink-0" />
            <span className="whitespace-nowrap">EXPLODING! 🔥</span>
          </div>
        )}
      </div>

      {/* Information Section */}
      <div className="mt-1 sm:mt-2">
        <div className="flex items-baseline justify-between gap-1 flex-wrap">
          <h3 className="text-xs min-[360px]:text-sm sm:text-base md:text-lg font-bold text-white tracking-wide group-hover:text-amber-300 transition-colors truncate">
            {cracker.name}
          </h3>
          <span className="text-[10px] min-[360px]:text-[11px] sm:text-xs text-amber-400 font-cinzel font-bold shrink-0">
            {cracker.hindiName}
          </span>
        </div>

        <p className="text-[10px] min-[360px]:text-[11px] sm:text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
          {cracker.tagline}
        </p>

        {/* Specs row */}
        <div className="flex items-center justify-between text-[9px] min-[360px]:text-[10px] sm:text-[11px] text-slate-400 mt-2 sm:mt-3 pt-2 border-t border-slate-800/80">
          <span className="flex items-center gap-1 font-medium">
            <Volume2 className="w-3 h-3 text-amber-500 shrink-0" />
            <span className="truncate">{cracker.specs.noiseLevel}</span>
          </span>
          <span className="text-slate-400 truncate max-w-[85px] sm:max-w-[110px] text-right font-medium">
            {cracker.specs.altitude}
          </span>
        </div>

        {/* Touch-Friendly Action Button (min-h 44px on mobile) */}
        <button
          type="button"
          disabled={isAnyActive && !isSelected}
          className={`w-full mt-2 sm:mt-3 min-h-[44px] py-2 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 touch-manipulation ${
            isBurning
              ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/30'
              : isExploding
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
              : 'bg-slate-800/90 hover:bg-amber-400 hover:text-slate-950 text-slate-200 border border-slate-700/80'
          }`}
        >
          <Flame className={`w-4 h-4 shrink-0 ${isBurning ? 'animate-bounce text-slate-950' : 'text-amber-400'}`} />
          <span className="font-extrabold truncate">
            {isBurning ? 'GET READY! 🔥' : isExploding ? 'BOOM! 💥' : 'Tap to Light'}
          </span>
        </button>
      </div>
    </div>
  );
};
