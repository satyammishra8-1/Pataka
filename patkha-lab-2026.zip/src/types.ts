export type CrackerId =
  | 'sutli_bomb'
  | 'atom_bomb'
  | 'ladi'
  | 'rocket'
  | 'anaar'
  | 'chakri'
  | 'phuljhadi'
  | 'thousand_wala'
  | 'flower_pot'
  | 'seven_shot'
  | 'red_bijli'
  | 'pencil_cracker'
  | 'twinkling_star'
  | 'sky_shot'
  | 'mega_blast'
  | 'naagin_goli'
  | 'bullet_bomb'
  | 'smoke_bomb'
  | 'whistling_siren'
  | 'hydro_bomb';

export type CrackerCategory = 'bomb' | 'fountain' | 'ground' | 'aerial' | 'sparkler' | 'chain' | 'novelty';

export interface CrackerData {
  id: CrackerId;
  name: string;
  hindiName: string;
  category: CrackerCategory;
  categoryLabel: string;
  tagline: string;
  description: string;
  fuseTime: number; // in milliseconds
  duration: number; // in milliseconds
  dangerLevel: 1 | 2 | 3 | 4 | 5;
  primaryColor: string;
  secondaryColor: string;
  sparkColors: string[];
  specs: {
    noiseLevel: 'Loud' | 'Very Loud' | 'Extremely Loud' | 'Gentle' | 'Moderate' | 'Sizzling';
    type: string;
    altitude: string;
  };
}

export type CrackerState = 'idle' | 'selected' | 'fuse_burning' | 'exploding' | 'finished';
