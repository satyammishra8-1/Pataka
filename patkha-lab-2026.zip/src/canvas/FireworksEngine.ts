/**
 * High-Performance HTML5 Canvas Fireworks & Particle Physics Engine
 * Handles custom particle behaviors for all 15 Diwali crackers:
 * - Gravity, air resistance, turbulence, alpha dissipation
 * - Realistic smoke simulation with gentle thermal lift
 * - Expanding shockwave rings & flash illumination
 * - Multi-stage rockets, spinning ground wheels (Chakri), fountain geysers (Anaar),
 *   continuous chains (Ladi/1000 Wala), and grand finales.
 */

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
  gravity: number;
  drag: number;
  flicker?: boolean;
  shape?: 'circle' | 'spark' | 'star' | 'paper';
  rotation?: number;
  rotationSpeed?: number;
  trail?: { x: number; y: number }[];
  maxTrailLength?: number;
}

export interface SmokeParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  maxSize: number;
  alpha: number;
  decay: number;
  color: string;
}

export interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  decay: number;
  color: string;
  lineWidth: number;
}

export interface RocketEntity {
  x: number;
  y: number;
  targetY: number;
  vx: number;
  vy: number;
  color: string;
  burstColors: string[];
  trail: { x: number; y: number }[];
  isDetonated: boolean;
  type: 'rocket' | 'skyshot' | 'sevenshot';
}

export class FireworksEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animationFrameId: number | null = null;
  private particles: Particle[] = [];
  private smokeParticles: SmokeParticle[] = [];
  private shockwaves: Shockwave[] = [];
  private rockets: RocketEntity[] = [];
  private activeEmitters: (() => void)[] = [];
  private isRunning: boolean = false;
  private width: number = 0;
  private height: number = 0;
  private onShakeCallback?: (intensity: number) => void;
  private flashAlpha: number = 0;

  constructor(canvas: HTMLCanvasElement, onShake?: (intensity: number) => void) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: true });
    if (!context) throw new Error('Could not get 2D context');
    this.ctx = context;
    this.onShakeCallback = onShake;
    this.resize();
    this.start();
  }

  public resize(): void {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.width = rect.width || window.innerWidth;
    this.height = rect.height || window.innerHeight;

    this.canvas.width = this.width * dpr;
    this.canvas.height = this.height * dpr;
    this.ctx.resetTransform?.();
    this.ctx.scale(dpr, dpr);
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    const loop = () => {
      this.update();
      this.render();
      if (this.isRunning) {
        this.animationFrameId = requestAnimationFrame(loop);
      }
    };
    this.animationFrameId = requestAnimationFrame(loop);
  }

  public stop(): void {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  public clear(): void {
    this.particles = [];
    this.smokeParticles = [];
    this.shockwaves = [];
    this.rockets = [];
    this.activeEmitters = [];
    this.flashAlpha = 0;
    this.ctx.clearRect(0, 0, this.width, this.height);
  }

  public triggerFlash(intensity: number = 0.5): void {
    this.flashAlpha = Math.min(0.85, intensity);
  }

  private shakeScreen(intensity: number = 10): void {
    if (this.onShakeCallback) {
      this.onShakeCallback(intensity);
    }
  }

  private update(): void {
    // Run active dynamic emitters (for fountains, ground wheels, continuous chains)
    if (this.activeEmitters.length > 0) {
      for (let i = this.activeEmitters.length - 1; i >= 0; i--) {
        this.activeEmitters[i]();
      }
    }

    // Flash decay
    if (this.flashAlpha > 0.01) {
      this.flashAlpha *= 0.88;
    } else {
      this.flashAlpha = 0;
    }

    // Update Shockwaves
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.radius += (sw.maxRadius - sw.radius) * 0.16 + 2;
      sw.alpha -= sw.decay;
      if (sw.alpha <= 0 || sw.radius >= sw.maxRadius) {
        this.shockwaves.splice(i, 1);
      }
    }

    // Update Rockets & Ascending Shells
    for (let i = this.rockets.length - 1; i >= 0; i--) {
      const r = this.rockets[i];
      r.trail.push({ x: r.x, y: r.y });
      if (r.trail.length > 12) r.trail.shift();

      r.x += r.vx;
      r.y += r.vy;

      // Emit rocket engine sparks
      if (Math.random() < 0.7) {
        this.particles.push({
          x: r.x + (Math.random() * 4 - 2),
          y: r.y + 4,
          vx: Math.random() * 2 - 1,
          vy: Math.random() * 2 + 1,
          color: '#f59e0b',
          size: Math.random() * 2.5 + 1,
          alpha: 0.9,
          decay: 0.04,
          gravity: 0.1,
          drag: 0.97
        });
      }

      // Check apex arrival
      if (r.vy >= 0 || r.y <= r.targetY) {
        this.rockets.splice(i, 1);
        if (r.type === 'rocket') {
          this.createPeonyBurst(r.x, r.y, r.burstColors, 110);
        } else if (r.type === 'skyshot') {
          this.createSkyShotBurst(r.x, r.y, r.burstColors);
        } else if (r.type === 'sevenshot') {
          this.createPeonyBurst(r.x, r.y, r.burstColors, 85);
        }
      }
    }

    // Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];

      if (p.trail) {
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > (p.maxTrailLength || 6)) p.trail.shift();
      }

      p.vx *= p.drag;
      p.vy *= p.drag;
      p.vy += p.gravity;

      p.x += p.vx;
      p.y += p.vy;

      if (p.rotation !== undefined && p.rotationSpeed) {
        p.rotation += p.rotationSpeed;
      }

      p.alpha -= p.decay;

      if (p.alpha <= 0 || p.size <= 0.2) {
        this.particles.splice(i, 1);
      }
    }

    // Update Smoke Particles
    for (let i = this.smokeParticles.length - 1; i >= 0; i--) {
      const s = this.smokeParticles[i];
      s.x += s.vx;
      s.y += s.vy;
      s.size += (s.maxSize - s.size) * 0.04;
      s.alpha -= s.decay;

      if (s.alpha <= 0) {
        this.smokeParticles.splice(i, 1);
      }
    }
  }

  private render(): void {
    // Semi-clear for silky motion trails
    this.ctx.clearRect(0, 0, this.width, this.height);

    // Render Flash Illumination
    if (this.flashAlpha > 0.01) {
      this.ctx.save();
      this.ctx.fillStyle = `rgba(255, 240, 200, ${this.flashAlpha})`;
      this.ctx.fillRect(0, 0, this.width, this.height);
      this.ctx.restore();
    }

    // Render Smoke Particles (underneath bright embers)
    for (const s of this.smokeParticles) {
      this.ctx.save();
      this.ctx.globalAlpha = Math.max(0, s.alpha);
      this.ctx.fillStyle = s.color;
      this.ctx.beginPath();
      this.ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }

    // Render Shockwaves
    for (const sw of this.shockwaves) {
      this.ctx.save();
      this.ctx.globalAlpha = Math.max(0, sw.alpha);
      this.ctx.strokeStyle = sw.color;
      this.ctx.lineWidth = sw.lineWidth;
      this.ctx.beginPath();
      this.ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      this.ctx.stroke();
      this.ctx.restore();
    }

    // Render Rocket Projectiles
    for (const r of this.rockets) {
      this.ctx.save();
      // Render rocket trail
      if (r.trail.length > 1) {
        this.ctx.beginPath();
        this.ctx.moveTo(r.trail[0].x, r.trail[0].y);
        for (let t = 1; t < r.trail.length; t++) {
          this.ctx.lineTo(r.trail[t].x, r.trail[t].y);
        }
        this.ctx.strokeStyle = 'rgba(251, 191, 36, 0.7)';
        this.ctx.lineWidth = 3;
        this.ctx.stroke();
      }
      // Rocket head
      this.ctx.fillStyle = r.color;
      this.ctx.beginPath();
      this.ctx.arc(r.x, r.y, 4, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }

    // Render Sparks & Embers (Additive blend mode for luminous magic!)
    this.ctx.save();
    this.ctx.globalCompositeOperation = 'lighter';

    for (const p of this.particles) {
      const flicker = p.flicker ? (Math.random() * 0.4 + 0.6) : 1;
      const alpha = Math.max(0, Math.min(1, p.alpha * flicker));

      // Render spark motion trail
      if (p.trail && p.trail.length > 1) {
        this.ctx.beginPath();
        this.ctx.moveTo(p.trail[0].x, p.trail[0].y);
        for (let t = 1; t < p.trail.length; t++) {
          this.ctx.lineTo(p.trail[t].x, p.trail[t].y);
        }
        this.ctx.strokeStyle = p.color;
        this.ctx.globalAlpha = alpha * 0.6;
        this.ctx.lineWidth = p.size * 0.8;
        this.ctx.stroke();
      }

      this.ctx.globalAlpha = alpha;
      this.ctx.fillStyle = p.color;

      if (p.shape === 'star') {
        this.drawStar(p.x, p.y, 5, p.size * 2, p.size);
      } else if (p.shape === 'paper') {
        this.ctx.save();
        this.ctx.translate(p.x, p.y);
        this.ctx.rotate(p.rotation || 0);
        this.ctx.fillRect(-p.size, -p.size * 0.5, p.size * 2, p.size);
        this.ctx.restore();
      } else {
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, Math.max(0.8, p.size), 0, Math.PI * 2);
        this.ctx.fill();
      }
    }

    this.ctx.restore();
  }

  private drawStar(cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number): void {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    this.ctx.beginPath();
    this.ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      this.ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      this.ctx.lineTo(x, y);
      rot += step;
    }
    this.ctx.lineTo(cx, cy - outerRadius);
    this.ctx.closePath();
    this.ctx.fill();
  }

  // ==========================================
  // BESPOKE CRACKER EXPLOSION EFFECTS
  // ==========================================

  /**
   * 1. SUTLI BOMB: Ground shockwave, explosive golden/red fragments, dense smoke
   */
  public triggerSutliBomb(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.62;

    this.triggerFlash(0.75);
    this.shakeScreen(18);

    // Shockwave ring
    this.shockwaves.push({
      x: cx,
      y: cy,
      radius: 10,
      maxRadius: Math.min(this.width, this.height) * 0.45,
      alpha: 1.0,
      decay: 0.035,
      color: '#f59e0b',
      lineWidth: 5
    });

    // 160 fiery particles with radial explosion
    const colors = ['#f59e0b', '#ef4444', '#fbbf24', '#ffffff', '#eab308'];
    for (let i = 0; i < 180; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 14 + 2;
      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 3.5 + 1.2,
        alpha: 1.0,
        decay: Math.random() * 0.02 + 0.012,
        gravity: 0.16,
        drag: 0.94,
        trail: [],
        maxTrailLength: 8
      });
    }

    // Jute twine fibers flying outwards
    for (let i = 0; i < 35; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 9 + 3;
      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        color: '#b45309',
        size: Math.random() * 3 + 1,
        alpha: 0.9,
        decay: 0.015,
        gravity: 0.18,
        drag: 0.92,
        shape: 'paper',
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.2
      });
    }

    // Rolling smoke cloud
    this.addSmokePuff(cx, cy, 18, 55);
  }

  /**
   * 2. ATOM BOMB: Green foil blast with secondary shockwave
   */
  public triggerAtomBomb(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.62;

    this.triggerFlash(0.8);
    this.shakeScreen(20);

    // Dual shockwave
    this.shockwaves.push({
      x: cx,
      y: cy,
      radius: 12,
      maxRadius: Math.min(this.width, this.height) * 0.48,
      alpha: 1.0,
      decay: 0.03,
      color: '#22c55e',
      lineWidth: 6
    });

    const colors = ['#22c55e', '#86efac', '#eab308', '#ffffff', '#15803d'];
    for (let i = 0; i < 200; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 15 + 3;
      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 3.8 + 1.2,
        alpha: 1.0,
        decay: Math.random() * 0.022 + 0.012,
        gravity: 0.16,
        drag: 0.93,
        trail: [],
        maxTrailLength: 7
      });
    }

    // Green and gold foil pieces
    for (let i = 0; i < 40; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 11 + 2;
      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 3,
        color: Math.random() > 0.4 ? '#4ade80' : '#facc15',
        size: Math.random() * 4 + 1.5,
        alpha: 1.0,
        decay: 0.012,
        gravity: 0.14,
        drag: 0.91,
        shape: 'paper',
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.25
      });
    }

    this.addSmokePuff(cx, cy, 22, 65);
  }

  /**
   * 3. LADI: Continuous runway of sequential pops & flying red paper
   */
  public triggerLadi(x?: number, y?: number): void {
    const startX = (x ?? this.width / 2) - 120;
    const cy = y ?? this.height * 0.7;
    const totalPops = 22;

    for (let i = 0; i < totalPops; i++) {
      setTimeout(() => {
        const curX = startX + i * 11 + (Math.random() * 16 - 8);
        const curY = cy + (Math.random() * 24 - 12);
        this.createMicroPop(curX, curY, ['#dc2626', '#ef4444', '#f59e0b', '#ffffff'], 20);
        this.addRedPaperDebris(curX, curY, 6);
        this.triggerFlash(0.2);
        this.shakeScreen(3);
      }, i * 130);
    }
  }

  /**
   * 4. ROCKET: Ascending rocket entity blooming into a peony burst
   */
  public triggerRocket(x?: number): void {
    const startX = x ?? this.width / 2;
    const startY = this.height * 0.85;
    const targetY = this.height * (0.2 + Math.random() * 0.15);

    this.rockets.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 2,
      vy: -13,
      color: '#ef4444',
      burstColors: ['#38bdf8', '#fbbf24', '#f43f5e', '#a855f7', '#4ade80'],
      trail: [],
      isDetonated: false,
      type: 'rocket'
    });
  }

  /**
   * 5. ANAAR: Continuous upward geyser of golden fountain sparks
   */
  public triggerAnaar(x?: number, y?: number, durationMs: number = 3800): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.78;

    const startTime = performance.now();
    const colors = ['#fef08a', '#fde047', '#f59e0b', '#fbbf24', '#ffffff', '#fb923c'];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      // Height envelope (starts small, reaches peak in middle, then tapers)
      const progress = elapsed / durationMs;
      const heightFactor = Math.sin(progress * Math.PI) * 0.8 + 0.2;
      const sparksPerFrame = Math.floor(10 * heightFactor) + 3;

      for (let i = 0; i < sparksPerFrame; i++) {
        // Conical spray upward
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * 0.55;
        const speed = (Math.random() * 11 + 6) * heightFactor;

        this.particles.push({
          x: cx + (Math.random() * 12 - 6),
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 3 + 1,
          alpha: 1.0,
          decay: Math.random() * 0.02 + 0.015,
          gravity: 0.22, // strong gravity creates cascading fountain shape
          drag: 0.96,
          flicker: true,
          trail: [],
          maxTrailLength: 4
        });
      }

      // Occasional small ground smoke
      if (Math.random() < 0.2) {
        this.smokeParticles.push({
          x: cx + (Math.random() * 20 - 10),
          y: cy - 10,
          vx: (Math.random() - 0.5) * 0.8,
          vy: -Math.random() * 1 - 0.5,
          size: 6,
          maxSize: 32,
          alpha: 0.35,
          decay: 0.01,
          color: 'rgba(180, 160, 140, 0.4)'
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 6. CHAKRI: High-speed spinning wheel ejecting spiral sparks
   */
  public triggerChakri(x?: number, y?: number, durationMs: number = 4000): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.72;

    const startTime = performance.now();
    let currentAngle = 0;
    const colors = ['#f59e0b', '#eab308', '#38bdf8', '#f97316', '#ffffff'];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        // Ending mini pop
        this.createMicroPop(cx, cy, ['#f59e0b', '#ffffff'], 30);
        return;
      }

      // Spin rate accelerates and then slowly winds down
      const progress = elapsed / durationMs;
      const spinSpeed = (1 - progress * 0.5) * 0.45;
      currentAngle += spinSpeed;

      const numJets = 3; // 3-nozzle spinning wheel
      for (let j = 0; j < numJets; j++) {
        const nozzleAngle = currentAngle + (j * Math.PI * 2) / numJets;
        // Sparks emit tangentially
        const tangentialAngle = nozzleAngle + Math.PI / 2;
        const speed = Math.random() * 7 + 4;

        this.particles.push({
          x: cx + Math.cos(nozzleAngle) * 16,
          y: cy + Math.sin(nozzleAngle) * 8, // slight perspective flattening
          vx: Math.cos(tangentialAngle) * speed + (Math.random() - 0.5) * 1.5,
          vy: Math.sin(tangentialAngle) * speed * 0.6 + (Math.random() - 0.5) * 1.5,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 2.8 + 1,
          alpha: 1.0,
          decay: Math.random() * 0.025 + 0.015,
          gravity: 0.05,
          drag: 0.95,
          trail: [],
          maxTrailLength: 5
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 7. PHULJHADI: Handheld sparkler with branching star embers
   */
  public triggerPhuljhadi(x?: number, y?: number, durationMs: number = 4500): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.55;

    const startTime = performance.now();
    const colors = ['#fef08a', '#fbbf24', '#ffffff', '#fed7aa'];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      // Subtle hand sway
      const swayX = Math.sin(elapsed * 0.003) * 18;
      const swayY = Math.cos(elapsed * 0.002) * 8;
      const tipX = cx + swayX;
      const tipY = cy + swayY;

      // Emit sharp needle-like sparks in all directions
      for (let i = 0; i < 7; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 6 + 2;

        this.particles.push({
          x: tipX,
          y: tipY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 2.2 + 0.8,
          alpha: 1.0,
          decay: Math.random() * 0.04 + 0.02,
          gravity: 0.12,
          drag: 0.92,
          flicker: true,
          trail: [],
          maxTrailLength: 5
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 8. 1000 WALA: Intense celebratory grand chain of explosions
   */
  public triggerThousandWala(x?: number, y?: number): void {
    const startX = (x ?? this.width / 2) - 180;
    const cy = y ?? this.height * 0.72;
    const totalPops = 44;

    for (let i = 0; i < totalPops; i++) {
      setTimeout(() => {
        const curX = startX + (i % 22) * 16 + (Math.random() * 20 - 10);
        const curY = cy + Math.floor(i / 22) * 20 + (Math.random() * 16 - 8);
        this.createMicroPop(curX, curY, ['#b91c1c', '#dc2626', '#f59e0b', '#ffffff'], 32);
        this.addRedPaperDebris(curX, curY, 8);
        this.triggerFlash(0.25);
        this.shakeScreen(5);

        // Heavy mid-chain bangs
        if (i % 8 === 0) {
          this.shockwaves.push({
            x: curX,
            y: curY,
            radius: 8,
            maxRadius: 90,
            alpha: 0.8,
            decay: 0.04,
            color: '#ef4444',
            lineWidth: 3
          });
        }
      }, i * 95);
    }
  }

  /**
   * 9. FLOWER POT: Tall rainbow floral fountain
   */
  public triggerFlowerPot(x?: number, y?: number, durationMs: number = 4200): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.8;

    const startTime = performance.now();
    const colors = ['#c084fc', '#34d399', '#f43f5e', '#fbbf24', '#ffffff', '#38bdf8'];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      const progress = elapsed / durationMs;
      const heightFactor = Math.sin(progress * Math.PI) * 0.9 + 0.3;
      const sparksCount = Math.floor(12 * heightFactor) + 4;

      for (let i = 0; i < sparksCount; i++) {
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * 0.45;
        const speed = (Math.random() * 14 + 8) * heightFactor;

        this.particles.push({
          x: cx + (Math.random() * 14 - 7),
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 3.2 + 1,
          alpha: 1.0,
          decay: Math.random() * 0.018 + 0.012,
          gravity: 0.2,
          drag: 0.96,
          flicker: true,
          trail: [],
          maxTrailLength: 6
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 10. SEVEN SHOT: 7 distinct sequential mortar shells in differing colors
   */
  public triggerSevenShot(x?: number): void {
    const startX = x ?? this.width / 2;
    const colorSets = [
      ['#ef4444', '#f87171', '#ffffff'], // Ruby Red
      ['#10b981', '#6ee7b7', '#ffffff'], // Emerald Green
      ['#3b82f6', '#93c5fd', '#ffffff'], // Sapphire Blue
      ['#f59e0b', '#fde047', '#ffffff'], // Golden Yellow
      ['#a855f7', '#d8b4fe', '#ffffff'], // Royal Violet
      ['#f97316', '#fdba74', '#ffffff'], // Tiger Orange
      ['#ffffff', '#e2e8f0', '#94a3b8']  // Shimmering Silver
    ];

    for (let i = 0; i < 7; i++) {
      setTimeout(() => {
        const targetX = startX + (i - 3) * 65 + (Math.random() * 40 - 20);
        const targetY = this.height * (0.18 + Math.random() * 0.18);

        this.rockets.push({
          x: startX,
          y: this.height * 0.85,
          targetY,
          vx: (targetX - startX) * 0.025,
          vy: -14,
          color: colorSets[i][0],
          burstColors: colorSets[i],
          trail: [],
          isDetonated: false,
          type: 'sevenshot'
        });
        this.shakeScreen(4);
      }, i * 650);
    }
  }

  /**
   * 11. RED BIJLI: Fast snappy red paper cracker
   */
  public triggerRedBijli(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.65;

    this.triggerFlash(0.4);
    this.shakeScreen(6);
    this.createMicroPop(cx, cy, ['#ef4444', '#f87171', '#fbbf24', '#ffffff'], 45);
    this.addRedPaperDebris(cx, cy, 14);
  }

  /**
   * 12. PENCIL CRACKER: Straight vertical jet of sparkling stars
   */
  public triggerPencilCracker(x?: number, y?: number, durationMs: number = 3200): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.75;

    const startTime = performance.now();
    const colors = ['#2dd4bf', '#fde047', '#ffffff', '#38bdf8'];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      for (let i = 0; i < 8; i++) {
        // Tight, high-velocity vertical jet
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * 0.18;
        const speed = Math.random() * 15 + 10;

        this.particles.push({
          x: cx + (Math.random() * 4 - 2),
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 2.5 + 1,
          alpha: 1.0,
          decay: Math.random() * 0.03 + 0.02,
          gravity: 0.18,
          drag: 0.95,
          flicker: true,
          trail: [],
          maxTrailLength: 5
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 13. TWINKLING STAR: Five-pointed starburst that drifts into glittering star clusters
   */
  public triggerTwinklingStar(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.5;

    this.triggerFlash(0.5);
    this.shakeScreen(7);

    const colors = ['#fde047', '#c084fc', '#ffffff', '#67e8f9', '#f472b6'];

    // 5 geometric star arms
    for (let arm = 0; arm < 5; arm++) {
      const baseAngle = (arm * Math.PI * 2) / 5 - Math.PI / 2;
      for (let i = 0; i < 24; i++) {
        const angle = baseAngle + (Math.random() - 0.5) * 0.3;
        const speed = Math.random() * 8 + 3;

        this.particles.push({
          x: cx,
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 3 + 1.5,
          alpha: 1.0,
          decay: Math.random() * 0.015 + 0.01,
          gravity: 0.04,
          drag: 0.96,
          shape: 'star',
          flicker: true
        });
      }
    }
  }

  /**
   * 14. SKY SHOT: Heavy mortar shell rising high into a grand willow burst
   */
  public triggerSkyShot(x?: number): void {
    const startX = x ?? this.width / 2;
    const startY = this.height * 0.88;
    const targetY = this.height * 0.22;

    this.rockets.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 1.5,
      vy: -15,
      color: '#818cf8',
      burstColors: ['#818cf8', '#fb7185', '#fde047', '#ffffff', '#a78bfa'],
      trail: [],
      isDetonated: false,
      type: 'skyshot'
    });
  }

  /**
   * 15. MEGA BLAST: Cinematic finale cracker with multiple shockwaves & 400+ particles
   */
  public triggerMegaBlast(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.58;

    this.triggerFlash(0.9);
    this.shakeScreen(26);

    // Triple shockwaves
    [0, 150, 300].forEach((delay, idx) => {
      setTimeout(() => {
        this.shockwaves.push({
          x: cx,
          y: cy,
          radius: 10,
          maxRadius: Math.min(this.width, this.height) * (0.45 + idx * 0.1),
          alpha: 1.0,
          decay: 0.025,
          color: idx === 0 ? '#ef4444' : idx === 1 ? '#f59e0b' : '#38bdf8',
          lineWidth: 6 - idx
        });
      }, delay);
    });

    const colors = ['#fbbf24', '#f43f5e', '#38bdf8', '#4ade80', '#c084fc', '#ffffff', '#f97316'];
    for (let i = 0; i < 350; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 18 + 3;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 4 + 1.5,
        alpha: 1.0,
        decay: Math.random() * 0.016 + 0.008,
        gravity: 0.14,
        drag: 0.94,
        flicker: true,
        trail: [],
        maxTrailLength: 10
      });
    }

    // Heavy smoke blanket
    this.addSmokePuff(cx, cy, 30, 80);
  }

  /**
   * BURST ALL: Coordinated full-screen Diwali finale
   */
  public triggerBurstAll(): void {
    this.triggerFlash(0.6);

    // Phase 1: 4 rockets shoot upward across screen
    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        const posX = this.width * (0.15 + i * 0.18);
        this.triggerRocket(posX);
      }, i * 350);
    }

    // Phase 2: Anaar fountains on left and right
    setTimeout(() => {
      this.triggerAnaar(this.width * 0.2, this.height * 0.8, 4000);
      this.triggerFlowerPot(this.width * 0.8, this.height * 0.8, 4000);
    }, 1200);

    // Phase 3: Seven shot aerial barrage in center
    setTimeout(() => {
      this.triggerSevenShot(this.width * 0.5);
    }, 1800);

    // Phase 4: Ground Ladi celebration across bottom
    setTimeout(() => {
      this.triggerLadi(this.width * 0.5, this.height * 0.85);
    }, 2400);

    // Phase 5: Mega Blast climax in center sky
    setTimeout(() => {
      this.triggerMegaBlast(this.width * 0.5, this.height * 0.35);
      this.triggerSkyShot(this.width * 0.35);
      this.triggerSkyShot(this.width * 0.65);
    }, 4200);
  }

  // ==========================================
  // HELPER METHODS
  // ==========================================

  private createPeonyBurst(cx: number, cy: number, colors: string[], count: number = 100): void {
    this.triggerFlash(0.45);
    this.shakeScreen(8);

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 10 + 2;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 3 + 1,
        alpha: 1.0,
        decay: Math.random() * 0.018 + 0.012,
        gravity: 0.1,
        drag: 0.95,
        flicker: true,
        trail: [],
        maxTrailLength: 6
      });
    }
  }

  private createSkyShotBurst(cx: number, cy: number, colors: string[]): void {
    this.triggerFlash(0.7);
    this.shakeScreen(15);

    // Inner core shockwave
    this.shockwaves.push({
      x: cx,
      y: cy,
      radius: 10,
      maxRadius: 180,
      alpha: 1.0,
      decay: 0.03,
      color: '#ffffff',
      lineWidth: 4
    });

    // 250 trailing willow particles
    for (let i = 0; i < 220; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 14 + 3;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 3.5 + 1.2,
        alpha: 1.0,
        decay: Math.random() * 0.012 + 0.008, // Slow decay for trailing willow effect
        gravity: 0.12,
        drag: 0.94,
        flicker: true,
        trail: [],
        maxTrailLength: 9
      });
    }
  }

  private createMicroPop(cx: number, cy: number, colors: string[], count: number = 25): void {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 1.5;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 2.5 + 1,
        alpha: 1.0,
        decay: Math.random() * 0.035 + 0.025,
        gravity: 0.15,
        drag: 0.93
      });
    }
  }

  private addRedPaperDebris(cx: number, cy: number, count: number = 8): void {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 1;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        color: Math.random() > 0.2 ? '#dc2626' : '#ef4444',
        size: Math.random() * 3.5 + 1.5,
        alpha: 0.9,
        decay: 0.015,
        gravity: 0.12,
        drag: 0.9,
        shape: 'paper',
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.2
      });
    }
  }

  private addSmokePuff(cx: number, cy: number, count: number = 15, maxSize: number = 50): void {
    for (let i = 0; i < count; i++) {
      this.smokeParticles.push({
        x: cx + (Math.random() * 30 - 15),
        y: cy + (Math.random() * 20 - 10),
        vx: (Math.random() - 0.5) * 1.5,
        vy: -Math.random() * 1.2 - 0.4, // smoke rises slowly
        size: Math.random() * 10 + 6,
        maxSize: maxSize + Math.random() * 20,
        alpha: 0.45,
        decay: Math.random() * 0.008 + 0.004,
        color: 'rgba(160, 150, 140, 0.4)'
      });
    }
  }

  /**
   * 16. BULLET BOMB: Supersonic sharp crack with high-velocity golden shrapnel
   */
  public triggerBulletBomb(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.65;

    this.triggerFlash(0.85);
    this.shakeScreen(18);

    // Concussive shockwave
    this.shockwaves.push({
      x: cx,
      y: cy,
      radius: 8,
      maxRadius: Math.min(this.width, this.height) * 0.42,
      alpha: 1.0,
      decay: 0.04,
      color: '#facc15',
      lineWidth: 5
    });

    // High velocity golden shrapnel sparks
    const colors = ['#fde047', '#f59e0b', '#ef4444', '#ffffff'];
    for (let i = 0; i < 160; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 18 + 4;

      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        size: Math.random() * 3.5 + 1,
        alpha: 1.0,
        decay: Math.random() * 0.025 + 0.015,
        gravity: 0.18,
        drag: 0.93,
        trail: [],
        maxTrailLength: 7
      });
    }

    this.addSmokePuff(cx, cy, 14, 50);
  }

  /**
   * 17. HYDRO BOMB: Iconic two-stage double explosion
   */
  public triggerHydroBomb(x?: number, y?: number): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.62;

    // Stage 1: Sharp acoustic flash pop
    this.triggerFlash(0.5);
    this.shakeScreen(8);
    this.shockwaves.push({
      x: cx,
      y: cy,
      radius: 6,
      maxRadius: 90,
      alpha: 0.9,
      decay: 0.05,
      color: '#38bdf8',
      lineWidth: 3
    });
    this.createMicroPop(cx, cy, ['#38bdf8', '#ffffff'], 40);

    // Stage 2: 220ms delayed massive seismic second blast
    setTimeout(() => {
      this.triggerFlash(0.9);
      this.shakeScreen(24);

      this.shockwaves.push({
        x: cx,
        y: cy,
        radius: 12,
        maxRadius: Math.min(this.width, this.height) * 0.5,
        alpha: 1.0,
        decay: 0.028,
        color: '#0284c7',
        lineWidth: 6
      });

      const colors = ['#38bdf8', '#818cf8', '#ffffff', '#facc15'];
      for (let i = 0; i < 220; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 16 + 3;

        this.particles.push({
          x: cx,
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 2,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 4 + 1.2,
          alpha: 1.0,
          decay: Math.random() * 0.018 + 0.01,
          gravity: 0.15,
          drag: 0.94,
          flicker: true,
          trail: [],
          maxTrailLength: 8
        });
      }

      this.addSmokePuff(cx, cy, 24, 70);
    }, 220);
  }

  /**
   * 18. WHISTLING SIREN: Ascending screaming rocket with oscillating sparks & sky burst
   */
  public triggerWhistlingSiren(x?: number): void {
    const startX = x ?? this.width / 2;
    const startY = this.height * 0.85;
    const targetY = this.height * 0.25;

    this.rockets.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 1.8,
      vy: -14,
      color: '#facc15',
      burstColors: ['#fde047', '#f97316', '#38bdf8', '#ffffff'],
      trail: [],
      isDetonated: false,
      type: 'rocket'
    });
  }

  /**
   * 19. NAAGIN GOLI: Thermal carbon snake rising and curling from ground tablet
   */
  public triggerNaaginGoli(x?: number, y?: number, durationMs: number = 4800): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.78;

    const startTime = performance.now();
    let snakeHeadX = cx;
    let snakeHeadY = cy;

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      // Snake crawls and wriggles upward
      snakeHeadX += Math.sin(elapsed * 0.008) * 1.2 + (Math.random() - 0.5) * 1.5;
      snakeHeadY -= 0.35 + Math.random() * 0.25;

      // Add dark carbon snake ash segments
      this.particles.push({
        x: snakeHeadX,
        y: snakeHeadY,
        vx: (Math.random() - 0.5) * 0.5,
        vy: -0.2,
        color: Math.random() > 0.3 ? '#1e293b' : '#334155',
        size: Math.random() * 4 + 3.5,
        alpha: 0.95,
        decay: 0.003, // slow decay keeps snake body visible
        gravity: 0.02,
        drag: 0.98,
        shape: 'circle'
      });

      // Glowing ember tip
      if (Math.random() < 0.6) {
        this.particles.push({
          x: snakeHeadX + (Math.random() * 4 - 2),
          y: snakeHeadY,
          vx: (Math.random() - 0.5) * 1.2,
          vy: -Math.random() * 1.5 - 0.5,
          color: Math.random() > 0.4 ? '#f97316' : '#facc15',
          size: Math.random() * 2 + 1,
          alpha: 1.0,
          decay: 0.03,
          gravity: 0.08,
          drag: 0.95,
          flicker: true
        });
      }

      // Rising thermal smoke
      if (Math.random() < 0.25) {
        this.smokeParticles.push({
          x: snakeHeadX,
          y: snakeHeadY - 5,
          vx: (Math.random() - 0.5) * 0.8,
          vy: -Math.random() * 1 - 0.5,
          size: 6,
          maxSize: 30,
          alpha: 0.38,
          decay: 0.008,
          color: 'rgba(140, 140, 150, 0.4)'
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  /**
   * 20. COLOR SMOKE BOMB: Dense plumes of saffron, green and cyan billowing smoke
   */
  public triggerSmokeBomb(x?: number, y?: number, durationMs: number = 4500): void {
    const cx = x ?? this.width / 2;
    const cy = y ?? this.height * 0.78;

    const startTime = performance.now();
    const smokeColors = [
      'rgba(249, 115, 22, 0.65)', // Vibrant Saffron
      'rgba(16, 185, 129, 0.65)', // Emerald Green
      'rgba(6, 182, 212, 0.65)',  // Cyan Blue
      'rgba(250, 204, 21, 0.65)'  // Gold Yellow
    ];

    const emitter = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed > durationMs) {
        const idx = this.activeEmitters.indexOf(emitter);
        if (idx !== -1) this.activeEmitters.splice(idx, 1);
        return;
      }

      // Spew 3 colorful smoke clouds per frame
      for (let i = 0; i < 2; i++) {
        const color = smokeColors[Math.floor(Math.random() * smokeColors.length)];
        this.smokeParticles.push({
          x: cx + (Math.random() * 16 - 8),
          y: cy + (Math.random() * 8 - 4),
          vx: (Math.random() - 0.5) * 2.2 + 0.6, // gentle wind drift
          vy: -Math.random() * 2 - 1.2,          // buoyant rising smoke
          size: Math.random() * 8 + 8,
          maxSize: Math.random() * 45 + 35,
          alpha: 0.7,
          decay: Math.random() * 0.006 + 0.004,
          color
        });
      }

      // Small spark nozzle glow
      if (Math.random() < 0.4) {
        this.particles.push({
          x: cx + (Math.random() * 6 - 3),
          y: cy,
          vx: (Math.random() - 0.5) * 2,
          vy: -Math.random() * 3 - 1,
          color: '#fbbf24',
          size: Math.random() * 2 + 1,
          alpha: 1.0,
          decay: 0.04,
          gravity: 0.1,
          drag: 0.95
        });
      }
    };

    this.activeEmitters.push(emitter);
  }

  public triggerCracker(id: string, x?: number, y?: number): void {
    switch (id) {
      case 'sutli_bomb':
        this.triggerSutliBomb(x, y);
        break;
      case 'atom_bomb':
        this.triggerAtomBomb(x, y);
        break;
      case 'ladi':
        this.triggerLadi(x, y);
        break;
      case 'thousand_wala':
        this.triggerThousandWala(x, y);
        break;
      case 'rocket':
        this.triggerRocket(x);
        break;
      case 'anaar':
        this.triggerAnaar(x, y);
        break;
      case 'chakri':
        this.triggerChakri(x, y);
        break;
      case 'phuljhadi':
        this.triggerPhuljhadi(x, y);
        break;
      case 'flower_pot':
        this.triggerFlowerPot(x, y);
        break;
      case 'seven_shot':
        this.triggerSevenShot(x);
        break;
      case 'red_bijli':
        this.triggerRedBijli(x, y);
        break;
      case 'pencil_cracker':
        this.triggerPencilCracker(x, y);
        break;
      case 'twinkling_star':
        this.triggerTwinklingStar(x, y);
        break;
      case 'sky_shot':
        this.triggerSkyShot(x);
        break;
      case 'mega_blast':
        this.triggerMegaBlast(x, y);
        break;
      case 'bullet_bomb':
        this.triggerBulletBomb(x, y);
        break;
      case 'hydro_bomb':
        this.triggerHydroBomb(x, y);
        break;
      case 'whistling_siren':
        this.triggerWhistlingSiren(x);
        break;
      case 'naagin_goli':
        this.triggerNaaginGoli(x, y);
        break;
      case 'smoke_bomb':
        this.triggerSmokeBomb(x, y);
        break;
      default:
        this.triggerSutliBomb(x, y);
    }
  }
}

